// ---- Resonant Context SDK Integration ----
// resonant-context.js and context-plugins.js are injected before this file.
// They attach window.ResonantContext and window.getPluginForDomain.

var _rcInstance = null;

var getOrInitRC = function () {
  if (_rcInstance) return _rcInstance;
  // Guards: SDK and plugin registry must both be loaded
  if (typeof ResonantContext === 'undefined' || typeof getPluginForDomain === 'undefined') {
    return null;
  }
  try {
    var plugin = getPluginForDomain(location.hostname);
    _rcInstance = ResonantContext.init({ plugin: plugin, debug: false });
  } catch (e) {
    console.warn('[RC] SDK init failed:', e);
    _rcInstance = null;
  }
  return _rcInstance;
};

// Auto-initialize on script load so observers start tracking immediately.
// Use a short delay so the DOM is settled before the first observe pass.
setTimeout(getOrInitRC, 500);

var calculateContextRichness = function (ctx) {
  // Returns 0-99 richness score:
  // 0-20:  URL only / text only
  // 20-50: text extracted
  // 50-80: viewport + forms tracked
  // 80-99: full Resonant Context with dwell times
  if (!ctx) return 10;
  var score = 20; // baseline: text present
  var visibleSections = (ctx.viewport && ctx.viewport.visibleSections) || [];
  var forms = ctx.forms || [];
  var clicks = (ctx.session && ctx.session.clickTrail) || [];
  var timeOnPage = (ctx.page && ctx.page.timeOnPageMs) || 0;

  if (visibleSections.length > 0) score += 25;
  if (forms.some(function (f) { return f.completeness > 0; })) score += 15;
  if (clicks.length > 0) score += 15;
  if (timeOnPage > 5000) score += 10;
  if (ctx.viewport && ctx.viewport.activeOverlay) score += 5;
  // Bonus: dwell data present (observers have been running)
  if (visibleSections.some(function (s) { return s.dwellMs > 2000; })) score += 9;

  return Math.min(99, score);
};

// ---- Security: Sanitization & Rate Limiting ----

// Patterns that look like prompt injection attempts
const INJECTION_PATTERNS = [
  /ignore\s+(?:previous|prior|above|all)\s+(?:instructions?|prompts?|context)/i,
  /system\s*:/i,
  /\[INST\]/i,
  /<\|im_start\|>/i,
  /<\|im_end\|>/i,
  /\[\[SYSTEM\]\]/i,
  /###\s*(?:instruction|system|assistant|human)/i,
  /you\s+are\s+now\s+(?:a|an|the)\s+/i,
  /disregard\s+(?:previous|your|all)\s+(?:instructions?|prompts?|training)/i,
  /act\s+as\s+(?:a|an|the)\s+(?:different|new|evil|unrestricted)/i,
];

const HTML_ENTITY_RE = /&(?:#\d+|#x[0-9a-f]+|[a-z]+);/gi;
const CONTROL_CHAR_RE = /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g;

const sanitizePageText = (raw) => {
  // Limit to 8000 chars (reduced from 12000 for security)
  let text = String(raw ?? "").slice(0, 8000);
  // Strip HTML entities
  text = text.replace(HTML_ENTITY_RE, " ");
  // Strip control characters (preserve \t \n \r)
  text = text.replace(CONTROL_CHAR_RE, "");
  return text;
};

const detectInjection = (text) => INJECTION_PATTERNS.some((pattern) => pattern.test(text));

const logSecurityEvent = (event) => {
  const entry = { ts: new Date().toISOString(), url: location.href, ...event };
  chrome.storage.local.get(["securityLog"], (result) => {
    const log = Array.isArray(result.securityLog) ? result.securityLog : [];
    const updated = [...log, entry].slice(-20); // keep last 20 events
    chrome.storage.local.set({ securityLog: updated });
  });
};

// Rate limiting for read_page: max 1 per 2 seconds
let lastReadPageAt = 0;
const READ_PAGE_COOLDOWN_MS = 2000;

// ---- Page Snapshot (base) ----

const pageSnapshot = () => {
  const rawText = document.body?.innerText ?? "";
  const hasSuspiciousContent = detectInjection(rawText);
  if (hasSuspiciousContent) {
    logSecurityEvent({ type: "injection_attempt_detected", snippet: rawText.slice(0, 200) });
  }
  const sanitizedText = sanitizePageText(rawText);
  return {
    title: document.title,
    url: location.href,
    text: sanitizedText,
    sanitized: true,
    links: Array.from(document.querySelectorAll("a[href]"))
      .slice(0, 80)
      .map((link) => ({
        text: link.textContent?.trim().slice(0, 160) ?? "",
        href: link.href,
      })),
    walletProviders: {
      phantomSolana: Boolean(globalThis.phantom?.solana?.isPhantom || globalThis.solana?.isPhantom),
      braveSolana: Boolean(globalThis.braveSolana?.isBraveWallet),
    },
    contextRichness: 10, // text only
  };
};

// ---- Rich Page Snapshot (Resonant Context enhanced) ----
// Replaces pageSnapshot() for read_page messages.
// Adds viewport awareness, form state, click trail, and navigation history.
// Falls back gracefully to pageSnapshot() if SDK is unavailable.

const richPageSnapshot = () => {
  const base = pageSnapshot();

  const rc = getOrInitRC();
  if (!rc) {
    // SDK not available — return base snapshot with text-only richness
    return base;
  }

  try {
    const ctx = rc.getContext();

    // Merge Resonant Context data into the snapshot
    base.visibleSections   = (ctx.viewport && ctx.viewport.visibleSections) || [];
    base.activeOverlay     = (ctx.viewport && ctx.viewport.activeOverlay)   || null;
    base.formState         = ctx.forms                                       || [];
    base.clickTrail        = (ctx.session && ctx.session.clickTrail)         || [];
    base.currentPage       = ctx.page                                        || {};
    base.navigationHistory = (ctx.session && ctx.session.navigation)         || [];
    base.contextRichness   = calculateContextRichness(ctx);
    base.rcDomain          = ctx.domain                                      || 'generic';
  } catch (e) {
    // SDK error — log and return base snapshot
    console.warn('[RC] getContext failed:', e);
    base.contextRichness = 10;
  }

  return base;
};

// ---- DOM Helpers ----

const visibleText = (element) =>
  (element.innerText || element.textContent || element.getAttribute("aria-label") || element.value || "").trim();

const candidateClickElements = () => [
  ...document.querySelectorAll(
    "button, a, [role='button'], input[type='button'], input[type='submit'], summary, [onclick]"
  ),
];

const clickVisibleText = (targetText) => {
  const needle = String(targetText ?? "").trim().toLowerCase();
  if (!needle) {
    return { ok: false, error: "No click target text was provided." };
  }
  const element = candidateClickElements().find((candidate) =>
    visibleText(candidate).toLowerCase().includes(needle)
  );
  if (!element) {
    return { ok: false, error: `No visible clickable element matched "${targetText}".` };
  }
  element.scrollIntoView({ block: "center", inline: "center", behavior: "auto" });
  const rect = element.getBoundingClientRect();
  const eventOptions = {
    bubbles: true,
    cancelable: true,
    composed: true,
    view: window,
    clientX: Math.round(rect.left + rect.width / 2),
    clientY: Math.round(rect.top + rect.height / 2),
  };
  for (const eventName of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
    const EventConstructor = eventName.startsWith("pointer") ? PointerEvent : MouseEvent;
    element.dispatchEvent(new EventConstructor(eventName, eventOptions));
  }
  element.click();
  return {
    ok: true,
    clickedText: visibleText(element).slice(0, 180),
    tagName: element.tagName.toLowerCase(),
  };
};

const editableCandidates = () =>
  [
    document.activeElement,
    document.querySelector("textarea[name='q']"),
    document.querySelector("input[name='q']"),
    document.querySelector("input[type='search']"),
    document.querySelector("textarea"),
    document.querySelector("input[type='text']"),
    document.querySelector("[contenteditable='true']"),
  ].filter(Boolean);

const isEditable = (element) =>
  element instanceof HTMLInputElement ||
  element instanceof HTMLTextAreaElement ||
  element?.isContentEditable;

const setNativeValue = (element, value) => {
  if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
    const proto =
      element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    setter?.call(element, value);
  } else if (element?.isContentEditable) {
    element.textContent = value;
  }
  element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
};

const typeIntoPage = ({ text, submit = false } = {}) => {
  const value = String(text ?? "").trim();
  if (!value) {
    return { ok: false, error: "No text was provided for typing." };
  }
  const element = editableCandidates().find(isEditable);
  if (!element) {
    return { ok: false, error: "No editable field was found on this page." };
  }
  element.scrollIntoView({ block: "center", inline: "center", behavior: "auto" });
  element.focus();
  setNativeValue(element, value);
  if (submit) {
    element.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true })
    );
    element.dispatchEvent(
      new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true, cancelable: true })
    );
    element.form?.requestSubmit?.();
  }
  return {
    ok: true,
    typedText: value,
    submitted: Boolean(submit),
    tagName: element.tagName.toLowerCase(),
    fieldName:
      element.getAttribute("name") ||
      element.getAttribute("aria-label") ||
      element.getAttribute("placeholder") ||
      "",
  };
};

// ---- Wallet Helpers ----

const detectSolanaProvider = () => {
  if (globalThis.phantom?.solana?.isPhantom) {
    return { name: "Phantom", obj: globalThis.phantom.solana };
  }
  if (globalThis.braveSolana?.isBraveWallet) {
    return { name: "Brave Wallet", obj: globalThis.braveSolana };
  }
  if (globalThis.solflare?.isSolflare) {
    return { name: "Solflare", obj: globalThis.solflare };
  }
  if (globalThis.solana?.isPhantom) {
    return { name: "Phantom (legacy)", obj: globalThis.solana };
  }
  if (globalThis.solana) {
    return { name: "Solana Wallet", obj: globalThis.solana };
  }
  return null;
};

const getSolBalance = async (address, network) => {
  const endpoint =
    network === "mainnet-beta"
      ? "https://api.mainnet-beta.solana.com"
      : "https://api.devnet.solana.com";
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "getBalance",
        params: [address],
      }),
    });
    const data = await res.json();
    const lamports = data?.result?.value ?? 0;
    return (lamports / 1_000_000_000).toFixed(4);
  } catch {
    return null;
  }
};

// ---- Message Listener ----

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.channel !== "resonantos.browser_first.content") {
    return false;
  }

  if (message.type === "read_page") {
    const now = Date.now();
    if (now - lastReadPageAt < READ_PAGE_COOLDOWN_MS) {
      logSecurityEvent({ type: "rate_limit_hit", detail: "read_page throttled" });
      sendResponse({ ok: false, error: "Rate limited: max 1 read_page per 2 seconds." });
      return true;
    }
    lastReadPageAt = now;
    // Use rich snapshot (Resonant Context) instead of dumb text-only snapshot
    sendResponse({ ok: true, snapshot: richPageSnapshot() });
    return true;
  }

  if (message.type === "click_text") {
    sendResponse(clickVisibleText(message.text));
    return true;
  }

  if (message.type === "type_text") {
    sendResponse(typeIntoPage({ text: message.text, submit: message.submit }));
    return true;
  }

  // ---- Wallet Actions ----

  if (message.type === "wallet_detect") {
    const detected = detectSolanaProvider();
    if (!detected) {
      sendResponse({ ok: true, provider: null, connected: false, address: null, network: null });
      return true;
    }
    const { name, obj } = detected;
    const connected = Boolean(obj.isConnected || obj.publicKey);
    const address = obj.publicKey ? String(obj.publicKey) : null;
    const network = obj.network ?? null;
    sendResponse({ ok: true, provider: name, connected, address, network: network || "mainnet-beta" });
    return true;
  }

  if (message.type === "wallet_connect") {
    const detected = detectSolanaProvider();
    if (!detected) {
      sendResponse({ ok: false, error: "No Solana wallet provider found on this page." });
      return true;
    }
    const { name, obj } = detected;
    (async () => {
      try {
        const result = await obj.connect();
        const address = result?.publicKey
          ? String(result.publicKey)
          : obj.publicKey
          ? String(obj.publicKey)
          : null;
        const network = obj.network ?? "mainnet-beta";
        sendResponse({ ok: true, provider: name, address, network });
      } catch (error) {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
      }
    })();
    return true; // keep channel open for async
  }

  if (message.type === "wallet_disconnect") {
    const detected = detectSolanaProvider();
    if (!detected) {
      sendResponse({ ok: true });
      return true;
    }
    const { obj } = detected;
    (async () => {
      try {
        await obj.disconnect();
        sendResponse({ ok: true });
      } catch (error) {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
      }
    })();
    return true; // keep channel open for async
  }

  if (message.type === "wallet_balance") {
    const address = String(message.address ?? "").trim();
    if (!address) {
      sendResponse({ ok: false, error: "No address provided for balance query." });
      return true;
    }
    const detected = detectSolanaProvider();
    const network = detected?.obj?.network ?? "mainnet-beta";
    (async () => {
      try {
        const balance = await getSolBalance(address, network);
        sendResponse({ ok: true, balance, network });
      } catch (error) {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
      }
    })();
    return true; // keep channel open for async
  }

  if (message.type === "wallet_sign_transaction") {
    // Transaction signing requires a Transaction object from @solana/web3.js.
    // This stub returns a clear error directing users to use Phantom directly.
    // Full implementation would require bundled Solana web3 or a base64 transaction
    // deserialized in the page context.
    sendResponse({
      ok: false,
      error: "Transaction signing requires direct Phantom interaction. Please sign in Phantom.",
    });
    return true;
  }

  // ---- Resonator Visual Guide Layer ----

  if (message.type === "resonator_highlight") {
    if (typeof window.Resonator === "undefined") {
      sendResponse({ ok: false, error: "Resonator not loaded" });
    } else {
      sendResponse(window.Resonator.highlight(message));
    }
    return true;
  }

  if (message.type === "resonator_arrow") {
    if (typeof window.Resonator === "undefined") {
      sendResponse({ ok: false, error: "Resonator not loaded" });
    } else {
      sendResponse(window.Resonator.arrow(message));
    }
    return true;
  }

  if (message.type === "resonator_spotlight") {
    if (typeof window.Resonator === "undefined") {
      sendResponse({ ok: false, error: "Resonator not loaded" });
    } else {
      sendResponse(window.Resonator.spotlight(message));
    }
    return true;
  }

  if (message.type === "resonator_step") {
    if (typeof window.Resonator === "undefined") {
      sendResponse({ ok: false, error: "Resonator not loaded" });
    } else {
      sendResponse(window.Resonator.step(message));
    }
    return true;
  }

  if (message.type === "resonator_clear") {
    if (typeof window.Resonator !== "undefined") window.Resonator.clear();
    sendResponse({ ok: true });
    return true;
  }

  sendResponse({ ok: false, error: "Unknown ResonantOS content command." });
  return true;
});

// ---------------------------------------------------------------------------
// Item 2: Settings / Provider Profiles
// ---------------------------------------------------------------------------
const settingsOpenButton = document.querySelector("#settings-open");
const settingsOverlay = document.querySelector("#settings-overlay");
const settingsClose = document.querySelector("#settings-close");
const settingsSave = document.querySelector("#settings-save");
const settingsStatus = document.querySelector("#settings-status");
const keyOpenAIInput = document.querySelector("#key-openai");
const keyMiniMaxInput = document.querySelector("#key-minimax");
const keyOpenAICurrent = document.querySelector("#key-openai-current");
const keyMiniMaxCurrent = document.querySelector("#key-minimax-current");

// ---------------------------------------------------------------------------
// Item 3: Wallet Banner
// ---------------------------------------------------------------------------
const walletBanner = document.querySelector("#wallet-banner");

import { injectWalletSection, getWalletState } from "./wallet-adapter.js";

const readButton = document.querySelector("#read-page");
const attachFileButton = document.querySelector("#attach-file");
const fileInput = document.querySelector("#file-input");
const attachmentStrip = document.querySelector("#attachment-strip");
const saveIntakeButton = document.querySelector("#save-intake");
const transcript = document.querySelector("#transcript");
const activityPanel = document.querySelector("#activity-panel");
const activityLabel = document.querySelector("#activity-label");
const activityDetail = document.querySelector("#activity-detail");
const commandForm = document.querySelector("#command-form");
const commandInput = document.querySelector("#command-input");
const contextMeter = document.querySelector("#context-meter");
const modelSelect = document.querySelector("#model-select");
const thinkingDepthSelect = document.querySelector("#thinking-depth");
const dictateButton = document.querySelector("#dictate-button");
const connectionLine = document.querySelector("#connection-line");

const BRIDGE_URL = "http://127.0.0.1:47773";
const bridgeBanner = document.getElementById("bridge-banner");

// ---- Offline Resilience ----

let bridgeOnline = true;
let offlineQueue = []; // max 5 queued messages
const OFFLINE_QUEUE_MAX = 5;
let healthCheckTimer = null;

const showBridgeBanner = (online) => {
  if (!bridgeBanner) return;
  if (online) {
    bridgeBanner.textContent = "✓ Bridge connected";
    bridgeBanner.className = "bridge-banner bridge-banner-online";
    bridgeBanner.hidden = false;
    // Auto-hide the online banner after 3 seconds
    window.setTimeout(() => {
      if (bridgeBanner.classList.contains("bridge-banner-online")) {
        bridgeBanner.hidden = true;
      }
    }, 3000);
  } else {
    bridgeBanner.textContent = "Bridge offline — start the ResonantOS bridge server";
    bridgeBanner.className = "bridge-banner bridge-banner-offline";
    bridgeBanner.hidden = false;
  }
};

const setBridgeOnline = (online) => {
  const wasOffline = !bridgeOnline;
  bridgeOnline = online;
  showBridgeBanner(online);
  if (online && wasOffline) {
    // Drain the offline queue
    const queued = [...offlineQueue];
    offlineQueue = [];
    for (const item of queued) {
      void respondToCommand(item);
    }
  }
};

// bridgeFetch: wraps all bridge calls with offline detection, retry, and banner
const bridgeFetch = async (route, options = {}) => {
  const url = `${BRIDGE_URL}${route}`;
  const fetchOptions = {
    method: options.method ?? "GET",
    headers: options.body ? { "Content-Type": "application/json" } : undefined,
    body: options.body ? JSON.stringify(options.body) : undefined,
  };

  const attempt = async () => {
    const response = await fetch(url, fetchOptions);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.ok) {
      throw new Error(payload?.error ?? `Bridge request failed with HTTP ${response.status}.`);
    }
    return payload;
  };

  try {
    const result = await attempt();
    if (!bridgeOnline) setBridgeOnline(true);
    return result;
  } catch (firstError) {
    // Check if it's a network error (bridge unreachable) vs. an API error
    const isNetworkError =
      firstError instanceof TypeError || String(firstError).includes("Failed to fetch") || String(firstError).includes("NetworkError");
    if (!isNetworkError) {
      // API-level error — no retry needed
      if (!bridgeOnline) setBridgeOnline(true); // bridge responded, just errored
      throw firstError;
    }
    // Network error: wait 2 seconds and retry once
    await new Promise((resolve) => window.setTimeout(resolve, 2000));
    try {
      const result = await attempt();
      setBridgeOnline(true);
      return result;
    } catch {
      setBridgeOnline(false);
      throw new Error("Bridge offline — start the ResonantOS bridge server");
    }
  }
};

const startHealthCheck = () => {
  if (healthCheckTimer) return;
  healthCheckTimer = window.setInterval(async () => {
    try {
      await bridgeFetch("/status");
      // If we get here, bridge is online — setBridgeOnline handles state
    } catch {
      // bridgeFetch already called setBridgeOnline(false)
    }
  }, 30_000);
};

const STORAGE_KEYS = {
  messages: "augmentorBrowserMessages",
  forks: "augmentorBrowserForks",
  model: "augmentorModel",
  thinkingDepth: "augmentorThinkingDepth",
  attachments: "augmentorBrowserAttachments",
  theme: "resonantosTheme"
};
const MAX_HISTORY_MESSAGES = 16;

let lastSnapshot = null;
let statusLabel = "Ready";
let messages = [];
let forks = [];
let attachments = [];
let turnBusy = false;
let activityTimer = null;

const MODEL_LABELS = {
  // OpenAI
  "gpt-5.5": "GPT 5.5",
  "gpt-5.4-mini": "GPT 5.4 Mini",
  "gpt-4o": "GPT-4o",
  // Anthropic
  "claude-sonnet-4": "Claude Sonnet 4",
  "claude-opus-4": "Claude Opus 4",
  // MiniMax
  "MiniMax-M2.7": "MiniMax 2.7",
  "MiniMax-M2.7-highspeed": "MiniMax 2.7 High Speed",
  // Groq
  "llama-3.3-70b-versatile": "Llama 3.3 70B",
  "llama-4-scout": "Llama 4 Scout",
  // DeepSeek
  "deepseek-chat": "DeepSeek Chat",
  "deepseek-reasoner": "DeepSeek Reasoner",
  // xAI
  "grok-4": "Grok 4",
  "grok-3": "Grok 3",
  // Local
  "batiai/gemma4-e2b:q4": "Gemma 4 2B",
};

const supportsThinkingDepth = (model) => model.startsWith("gpt-5.");

const isReadableBrowserTab = (tab) => typeof tab?.url === "string" && /^https?:\/\//i.test(tab.url);
const browserIntentVerbs = /\b(open|go\s+to|go\s+on|navi\w*(?:\s+to)?|visit|load|browse(?:\s+to)?|take\s+me\s+to|show\s+me|bring\s+up|pull\s+up)\b/i;
const browserTargetPattern = /\b((?:https?:\/\/)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s"'<>)]*)?)/i;
const searchIntentVerbs = /\b(search|find|look\s+up|research|news|latest|internet|web)\b/i;

const setStatus = (label) => {
  statusLabel = label;
  updateConnectionLine();
};

const setActivity = (phase, label, detail = "") => {
  if (activityTimer) {
    window.clearTimeout(activityTimer);
    activityTimer = null;
  }
  activityPanel.hidden = false;
  activityPanel.dataset.phase = phase;
  activityLabel.textContent = label;
  activityDetail.textContent = detail;
};

const clearActivity = () => {
  activityPanel.hidden = true;
  activityPanel.dataset.phase = "idle";
  activityLabel.textContent = "Ready";
  activityDetail.textContent = "";
};

const clearActivitySoon = (delay = 2200) => {
  if (activityTimer) {
    window.clearTimeout(activityTimer);
  }
  activityTimer = window.setTimeout(clearActivity, delay);
};

const setTurnBusy = (busy) => {
  turnBusy = busy;
  commandInput.disabled = busy;
  commandForm.querySelector(".send-button").disabled = busy;
};

const updateConnectionLine = () => {
  const model = MODEL_LABELS[modelSelect.value] ?? modelSelect.value;
  thinkingDepthSelect.hidden = !supportsThinkingDepth(modelSelect.value);
  connectionLine.textContent = `Connected to ${model} · ${statusLabel}`;
};

const setContextMeter = (snapshot) => {
  if (!snapshot) {
    contextMeter.textContent = "0%";
    return;
  }
  // Prefer Resonant Context richness score (0-99) set by content.js
  if (typeof snapshot.contextRichness === "number") {
    contextMeter.textContent = `${snapshot.contextRichness}%`;
    // Tooltip: describe what's driving the score
    const parts = [];
    if ((snapshot.visibleSections?.length ?? 0) > 0) parts.push("viewport");
    if ((snapshot.formState?.filter((f) => f.completeness > 0).length ?? 0) > 0) parts.push("forms");
    if ((snapshot.clickTrail?.length ?? 0) > 0) parts.push("clicks");
    if (snapshot.activeOverlay) parts.push("overlay");
    contextMeter.title = parts.length
      ? `Resonant Context active: ${parts.join(", ")}`
      : "Page text captured";
    return;
  }
  // Fallback: estimate from raw text length
  const textLength = snapshot?.text?.length ?? 0;
  const roughPercent = Math.min(49, Math.max(0, Math.round(textLength / 900)));
  contextMeter.textContent = `${roughPercent}%`;
  contextMeter.title = "Text only";
};

const renderAttachments = () => {
  attachmentStrip.replaceChildren();
  attachmentStrip.hidden = attachments.length === 0;
  attachments.forEach((attachment) => {
    const chip = document.createElement("span");
    chip.className = "attachment-chip";
    const label = document.createElement("strong");
    label.textContent = attachment.name;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "×";
    remove.title = `Remove ${attachment.name}`;
    remove.addEventListener("click", () => {
      attachments = attachments.filter((item) => item.id !== attachment.id);
      renderAttachments();
      void persistChatState();
    });
    chip.append(label, remove);
    attachmentStrip.append(chip);
  });
};

const clearAttachments = async () => {
  attachments = [];
  renderAttachments();
  await persistChatState();
};

const persistChatState = async () => {
  await chrome.storage?.local?.set?.({
    [STORAGE_KEYS.messages]: messages,
    [STORAGE_KEYS.forks]: forks,
    [STORAGE_KEYS.model]: modelSelect.value,
    [STORAGE_KEYS.thinkingDepth]: thinkingDepthSelect.value,
    [STORAGE_KEYS.attachments]: attachments
  }).catch(() => undefined);
};

// bridgeRequest now delegates to bridgeFetch for offline resilience
const bridgeRequest = (route, options = {}) => bridgeFetch(route, options);

const messageLabel = (role) => {
  if (role === "user") return "You";
  if (role === "system") return "System";
  return "Augmentor";
};

const ACTION_ICONS = {
  archive: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M6 7v13h12V7"/><path d="M9 11h6"/><path d="M9 15h6"/><path d="M8 4h8l2 3H6l2-3Z"/></svg>',
  check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
  copy: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 8.5A2.5 2.5 0 0 1 10.5 6h7A2.5 2.5 0 0 1 20 8.5v7a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 8 15.5v-7Z"/><path d="M5.5 14A2.5 2.5 0 0 1 3 11.5v-7A2.5 2.5 0 0 1 5.5 2h7A2.5 2.5 0 0 1 15 4.5"/></svg>',
  edit: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4l11-11a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></svg>',
  fork: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4v5a4 4 0 0 0 4 4h4"/><path d="M18 4v16"/><path d="m14 9 4 4-4 4"/><circle cx="6" cy="4" r="2"/><circle cx="18" cy="4" r="2"/><circle cx="18" cy="20" r="2"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.34 5.66"/><path d="M20 4v7h-7"/></svg>',
  stats: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19h16"/><path d="M7 16V9"/><path d="M12 16V5"/><path d="M17 16v-4"/></svg>',
  delete: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M7 7l1 13h8l1-13"/><path d="M10 11v5"/><path d="M14 11v5"/></svg>'
};

const actionButton = (action, label, title, onClick) => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "message-action";
  button.dataset.action = action;
  button.setAttribute("aria-label", label);
  button.title = title;
  button.innerHTML = ACTION_ICONS[action];
  button.addEventListener("click", onClick);
  return button;
};

const renderMessages = () => {
  transcript.replaceChildren();
  messages.forEach((message) => {
    const article = document.createElement("article");
    article.className = `message ${message.role}`;
    article.dataset.messageId = message.id;

    const header = document.createElement("div");
    header.className = "message-header";
    const strong = document.createElement("strong");
    strong.textContent = messageLabel(message.role);
    const time = document.createElement("time");
    time.textContent = new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    header.append(strong, time);

    const paragraph = document.createElement("p");
    paragraph.textContent = message.content;

    const actions = document.createElement("div");
    actions.className = "message-actions";
    actions.append(actionButton("copy", "Copy", "Copy this message", () => void copyMessage(message.id)));
    actions.append(actionButton("fork", "Fork", "Fork the conversation up to this message", () => void forkFromMessage(message.id)));
    if (message.role === "user") {
      actions.append(actionButton("edit", "Edit", "Edit this message in the composer", () => editMessage(message.id)));
    }
    if (message.role === "assistant") {
      actions.append(actionButton("archive", "Save to Living Archive", "Save this message to Living Archive intake", () => void saveMessageToArchive(message.id)));
      actions.append(actionButton("refresh", "Regenerate", "Regenerate from the previous user message", () => void regenerateFromMessage(message.id)));
      if (message.usage) {
        actions.append(actionButton("stats", "Stats", "Show generation stats", () => void showMessageStats(message.id)));
      }
    }
    actions.append(actionButton("delete", "Delete", "Delete this message", () => void deleteMessage(message.id)));

    article.append(header, paragraph, actions);
    transcript.append(article);
  });
  transcript.scrollTop = transcript.scrollHeight;
};

const addMessage = async (role, content, { persist = true, usage = null } = {}) => {
  const text = String(content ?? "").trim();
  if (!text) return null;
  const message = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    role,
    content: text,
    usage,
    createdAt: new Date().toISOString()
  };
  messages = [...messages, message];
  renderMessages();
  if (persist) {
    await persistChatState();
  }
  return message;
};

const copyMessage = async (id) => {
  const message = messages.find((item) => item.id === id);
  if (!message) return;
  await navigator.clipboard?.writeText?.(message.content).catch(() => undefined);
  const button = transcript.querySelector(`[data-message-id="${CSS.escape(id)}"] .message-action[data-action="copy"]`);
  if (button) {
    button.innerHTML = ACTION_ICONS.check;
    window.setTimeout(() => {
      button.innerHTML = ACTION_ICONS.copy;
    }, 1400);
  }
  setStatus("Copied");
};

const forkFromMessage = async (id) => {
  const index = messages.findIndex((item) => item.id === id);
  if (index < 0) return;
  const fork = {
    id: `fork-${Date.now()}`,
    sourceMessageId: id,
    createdAt: new Date().toISOString(),
    messages: messages.slice(0, index + 1)
  };
  forks = [...forks, fork];
  messages = fork.messages.map((message) => ({ ...message }));
  renderMessages();
  await persistChatState();
  setStatus("Forked");
};

const deleteMessage = async (id) => {
  messages = messages.filter((message) => message.id !== id);
  renderMessages();
  await persistChatState();
  setStatus("Deleted");
};

const editMessage = (id) => {
  const message = messages.find((item) => item.id === id);
  if (!message || message.role !== "user") return;
  commandInput.value = message.content;
  commandInput.focus();
  setStatus("Editing");
};

const saveMessageToArchive = async (id) => {
  const message = messages.find((item) => item.id === id);
  if (!message) return;
  setStatus("Saving");
  try {
    const result = await bridgeRequest("/archive/intake", {
      method: "POST",
      body: {
        title: `Augmentor message ${new Date(message.createdAt).toLocaleString()}`,
        content: message.content,
        sourceMessageId: message.id,
        url: lastSnapshot?.url ?? null
      }
    });
    await addMessage("system", `Saved to Living Archive intake: ${result.path}`);
    setStatus("Ready");
  } catch (error) {
    setStatus("Archive failed");
    await addMessage("system", error instanceof Error ? error.message : String(error));
  }
};

const showMessageStats = async (id) => {
  const message = messages.find((item) => item.id === id);
  if (!message?.usage) {
    await addMessage("system", "No generation telemetry is available for this message.");
    return;
  }
  await addMessage("system", `Generation stats:\n${JSON.stringify(message.usage, null, 2)}`);
};

const regenerateFromMessage = async (id) => {
  const index = messages.findIndex((item) => item.id === id);
  if (index < 0) return;
  const userIndex = messages.slice(0, index).findLastIndex((message) => message.role === "user");
  if (userIndex < 0) {
    await addMessage("system", "No previous user message is available for regeneration.");
    return;
  }
  messages = messages.slice(0, userIndex + 1);
  renderMessages();
  await persistChatState();
  await respondToCommand(messages[userIndex].content);
};

const activeTab = async () => {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const activeReadable = tabs.find((tab) => tab.active && isReadableBrowserTab(tab));
  if (activeReadable) {
    return activeReadable;
  }
  const readableTabs = tabs.filter(isReadableBrowserTab);
  return readableTabs.at(-1) ?? tabs.find((tab) => tab.active);
};

const normalizeBrowserUrl = (target) => {
  const trimmed = String(target ?? "").trim().replace(/[.,;:!?]+$/, "");
  if (!trimmed) {
    throw new Error("Browser navigation requires a URL or domain.");
  }
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const url = new URL(withProtocol);
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only http and https browser navigation is supported.");
  }
  return url.toString();
};

const parseNaturalBrowserIntent = (message) => {
  const normalized = message.trim();
  if (/^\//.test(normalized) || !browserIntentVerbs.test(normalized)) {
    return null;
  }
  const target = browserTargetPattern.exec(normalized)?.[1];
  if (!target) {
    return null;
  }
  return { action: "open", target };
};

const quotedTextPattern = /["“”'‘’]([^"“”'‘’]{1,280})["“”'‘’]/;

const parseQuotedText = (message) => quotedTextPattern.exec(String(message ?? ""))?.[1]?.trim() ?? "";

const parseTypeIntent = (message) => {
  const normalized = String(message ?? "").trim();
  if (/^\//.test(normalized) || !/\b(type|write|enter|put|insert)\b/i.test(normalized)) {
    return null;
  }
  const text = parseQuotedText(normalized);
  if (!text) {
    return null;
  }
  const submit = /\b(search bar|google|search field|address bar|submit|press enter|hit enter)\b/i.test(normalized);
  return { text, submit };
};

const parseClickIntent = (message) => {
  const normalized = String(message ?? "").trim();
  if (/^\//.test(normalized) || !/\b(click|press|tap|select|open)\b/i.test(normalized)) {
    return null;
  }
  const text = parseQuotedText(normalized);
  if (!text) {
    return null;
  }
  return { text };
};

const parseReadPageIntent = (message) => {
  const normalized = String(message ?? "").trim();
  if (/^\//.test(normalized)) {
    return null;
  }
  return (
    /\b(read|scan|summari[sz]e|inspect|look at|understand|see|view|access)\b/i.test(normalized) ||
    /\b(can you|do you)\s+(see|view|access)\b/i.test(normalized)
  ) &&
    /\b(this|current|active|the|open)\s+(page|website|webpage|site|tab|browser|window)\b/i.test(normalized)
    ? { action: "read_page" }
    : null;
};

const parseStructuredPageEditIntent = (message) => {
  const normalized = String(message ?? "").trim();
  if (/^\//.test(normalized) || !/\b(add|edit|update|write|insert|change|replace)\b/i.test(normalized)) {
    return null;
  }
  if (!/\b(doc|document|sheet|spreadsheet|page|row|line|cell|google\s+(sheet|doc|docs|sheets))\b/i.test(normalized)) {
    return null;
  }
  return { action: "structured_page_edit", instruction: normalized };
};

const normalizeSearchQuery = (message) => {
  const cleaned = String(message ?? "")
    .replace(/\b(can you|please|could you|would you)\b/gi, " ")
    .replace(/\b(search|find|look\s+up|research|on the internet|on internet|online|web|the web|some)\b/gi, " ")
    .replace(/[?.!]+$/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned || /^news$/i.test(cleaned) || /^latest news$/i.test(cleaned)) {
    return "top stories";
  }
  return cleaned;
};

const parseNaturalSearchIntent = (message) => {
  const normalized = message.trim();
  if (/^\//.test(normalized) || !searchIntentVerbs.test(normalized)) {
    return null;
  }
  if (browserTargetPattern.test(normalized) && browserIntentVerbs.test(normalized)) {
    return null;
  }
  const wantsNews = /\b(news|latest)\b/i.test(normalized);
  return {
    action: wantsNews ? "news" : "search",
    query: normalizeSearchQuery(normalized)
  };
};

const openBrowserUrl = async (target) => {
  const url = normalizeBrowserUrl(target);
  const targetTab = await activeTab();
  setActivity("tool-running", "Navigating browser", url);
  setStatus("Navigating");
  if (targetTab?.id && isReadableBrowserTab(targetTab)) {
    await chrome.tabs.update(targetTab.id, { url, active: true });
  } else {
    await chrome.tabs.create({ url, active: true });
  }
  lastSnapshot = null;
  setContextMeter(null);
  await addMessage("system", `Opened ${url}`);
  setStatus("Ready");
};

const searchBrowser = async ({ query, action }) => {
  const url = action === "news"
    ? `https://www.bing.com/news/search?q=${encodeURIComponent(query)}&setlang=en-US`
    : `https://www.google.com/search?q=${encodeURIComponent(query)}`;
  setActivity("tool-running", action === "news" ? "Searching news" : "Searching web", query);
  setStatus(action === "news" ? "Searching news" : "Searching web");
  const targetTab = await activeTab();
  if (targetTab?.id && isReadableBrowserTab(targetTab)) {
    await chrome.tabs.update(targetTab.id, { url, active: true });
  } else {
    await chrome.tabs.create({ url, active: true });
  }
  lastSnapshot = null;
  setContextMeter(null);
  if (action === "news") {
    const news = await bridgeRequest("/web/news", {
      method: "POST",
      body: { query, limit: 5 }
    }).catch((error) => ({ error: error instanceof Error ? error.message : String(error), items: [] }));
    const headlines = news.items?.length
      ? `\n\nTop headlines:\n${news.items.map((item, index) => `${index + 1}. ${item.title}${item.source ? ` — ${item.source}` : ""}`).join("\n")}`
      : `\n\nI opened the news search, but headline extraction failed${news.error ? `: ${news.error}` : "."}`;
    await addMessage("system", `Opened news search for "${query}".${headlines}`);
  } else {
    await addMessage("system", `Opened web search for "${query}".`);
  }
  setActivity("completed", action === "news" ? "News search opened" : "Web search opened", query);
  setStatus("Ready");
};

const ensureContentScriptInjected = async (tabId) => {
  try {
    // Try sending a ping — if content script is already there, it'll respond
    await chrome.tabs.sendMessage(tabId, { channel: "resonantos.browser_first.content", type: "read_page" });
  } catch {
    // Content script not present — inject in order:
    // 1. Resonant Context SDK (sets window.ResonantContext)
    // 2. Domain plugin configs (sets window.getPluginForDomain)
    // 3. Main content script (uses both of the above)
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/resonant-context.js", "src/context-plugins.js", "src/resonator.js", "src/content.js"],
    });
    // Brief wait for SDK observers to initialize
    await new Promise((r) => setTimeout(r, 500));
  }
};

const sendContentAction = async (payload) => {
  const tab = await activeTab();
  if (!tab?.id || !isReadableBrowserTab(tab)) {
    return { ok: false, error: "No normal web page is active for this browser action." };
  }
  // Inject content script on-demand (C1 security fix — no auto-inject on every page)
  await ensureContentScriptInjected(tab.id);
  return chrome.tabs.sendMessage(tab.id, {
    channel: "resonantos.browser_first.content",
    ...payload
  }).catch((error) => ({ ok: false, error: String(error) }));
};

const typeIntoActivePage = async ({ text, submit }) => {
  setActivity("tool-running", "Typing into page", text);
  setStatus("Typing");
  const response = await sendContentAction({ type: "type_text", text, submit });
  if (response?.ok) {
    await addMessage(
      "system",
      `Typed into the active page${response.submitted ? " and submitted it" : ""}: "${response.typedText}"`
    );
    setStatus("Ready");
    setActivity("completed", "Typed into page", response.fieldName || response.tagName || "active field");
    return;
  }
  await addMessage("system", `I could not type into the page: ${response?.error ?? "unknown error"}`);
  setStatus("Page action failed");
  setActivity("failed", "Typing failed", response?.error ?? "unknown error");
};

const clickActivePageText = async ({ text }) => {
  setActivity("tool-running", "Clicking page element", text);
  setStatus("Clicking");
  const response = await sendContentAction({ type: "click_text", text });
  if (response?.ok) {
    await addMessage("system", `Clicked "${response.clickedText || text}" on the active page.`);
    setStatus("Ready");
    setActivity("completed", "Clicked page element", response.clickedText || text);
    return;
  }
  await addMessage("system", `I could not click "${text}": ${response?.error ?? "unknown error"}`);
  setStatus("Page action failed");
  setActivity("failed", "Click failed", response?.error ?? "unknown error");
};

const refreshTabContext = async () => {
  setStatus("Reading");
  const tab = await activeTab();
  const label = tab?.title || tab?.url || "No page context";
  readButton.title = `Attach/read current page: ${label}`;
  setStatus("Ready");
  return tab;
};

const readActivePage = async ({ announce = true } = {}) => {
  const tab = await refreshTabContext();
  if (!tab?.id || !isReadableBrowserTab(tab)) {
    if (announce) {
      await addMessage("system", "I cannot read this tab yet. Open a normal web page and try again.");
    }
    return null;
  }
  // Ensure content script + resonant context SDK are injected before reading
  await ensureContentScriptInjected(tab.id);

  setActivity("reading", "Reading browser page", tab.title || tab.url);
  setStatus("Reading page");
  const response = await chrome.tabs.sendMessage(tab.id, {
    channel: "resonantos.browser_first.content",
    type: "read_page"
  }).catch((error) => ({ ok: false, error: String(error) }));

  lastSnapshot = response?.snapshot ?? null;
  if (lastSnapshot) lastSnapshot._capturedAt = Date.now();
  setContextMeter(lastSnapshot);
  updateWalletBanner(lastSnapshot);
  setStatus(response?.ok ? "Ready" : "Read failed");
  if (announce) {
    await addMessage(
      "system",
      response?.ok
        ? `Page context attached: ${response.snapshot.title || "Untitled"}\n${response.snapshot.url}`
        : `I could not read the page: ${response?.error ?? "unknown error"}`
    );
  }
  return response;
};

const attachFiles = async (fileList) => {
  const files = Array.from(fileList ?? []);
  if (!files.length) return;
  const nextAttachments = [];
  for (const [index, file] of files.entries()) {
    const textLike = /^(text\/|application\/(json|xml|javascript|typescript))/i.test(file.type) || /\.(md|txt|json|csv|ts|tsx|js|jsx|css|html|xml|yaml|yml)$/i.test(file.name);
    let content = "";
    if (textLike && file.size <= 64 * 1024) {
      content = (await file.text()).slice(0, 12000);
    }
    nextAttachments.push({
      id: `${file.name}-${file.size}-${Date.now()}-${index}`,
      name: file.name,
      size: file.size,
      type: file.type,
      summary: `${Math.round(file.size / 1024)} KB${content ? " · embedded text" : " · metadata only"}`,
      content
    });
  }
  attachments = [...attachments, ...nextAttachments];
  fileInput.value = "";
  renderAttachments();
  await persistChatState();
  setStatus("Attached");
};

const summarizeSnapshot = async () => {
  const response = lastSnapshot ? { ok: true, snapshot: lastSnapshot } : await readActivePage({ announce: false });
  const snapshot = response?.snapshot;
  if (!snapshot) {
    await addMessage("system", "No page context is attached yet. Use the plus button first.");
    return;
  }

  const text = snapshot.text || "";
  setActivity("reading", "Summarising page context", snapshot.title || snapshot.url);
  const words = text.split(/\s+/).filter(Boolean);
  const excerpt = words.slice(0, 46).join(" ");
  await addMessage(
    "system",
    `Page context captured.\n\nTitle: ${snapshot.title || "Untitled"}\nURL: ${snapshot.url}\nVisible text: about ${words.length} words.\nLinks found: ${snapshot.links?.length ?? 0}.\n\nOpening signal: ${excerpt}${words.length > 46 ? "..." : ""}`
  );
};

const saveIntake = async () => {
  const response = lastSnapshot ? { ok: true, snapshot: lastSnapshot } : await readActivePage({ announce: false });
  if (!response?.snapshot) {
    await addMessage("system", "There is no browser context to prepare for intake yet.");
    return;
  }
  setActivity("tool-running", "Preparing archive intake", response.snapshot.title || response.snapshot.url);
  await addMessage(
    "system",
    "Prepared this page as a Living Archive intake artifact. It remains raw/intake data only; trusted memory promotion must happen through the governed archive ingest path."
  );
  setStatus("Intake ready");
};

const explainStructuredPageEditBoundary = async (instruction) => {
  const response = lastSnapshot ? { ok: true, snapshot: lastSnapshot } : await readActivePage({ announce: false });
  const snapshot = response?.snapshot;
  const title = snapshot?.title || "the active page";
  const url = snapshot?.url || "unknown URL";
  setActivity("completed", "Checked active page", title);
  setStatus("Needs precise edit target");
  await addMessage(
    "system",
    [
      `I can see the active page: ${title}`,
      url,
      "",
      "I can read the page, click visible page controls, and type into focused or normal editable fields from the side-panel host.",
      "This request is a structured document edit, so I need a precise editable target before I act. For Google Sheets/Docs, line/row edits are canvas/app-level interactions and should not be guessed from visible text.",
      "",
      `Requested change: ${instruction}`,
      "",
      "Give me a specific target such as a cell address, visible button/text to click, or ask me to type quoted text into the currently focused field. Example: click cell A17, then ask: type \"we need to add model selection and providers to ResonantOS browser\"."
    ].join("\n")
  );
};

// ── Rich context formatter for Augmentor's system prompt ─────────────────────
const formatRichPageContext = (snapshot) => {
  const parts = [];

  // Page identity
  const hostname = (() => {
    try { return new URL(snapshot.url || "").hostname; } catch { return ""; }
  })();
  const domain = snapshot.rcDomain && snapshot.rcDomain !== "generic"
    ? snapshot.rcDomain
    : hostname;
  parts.push(`Page: ${snapshot.title || "Untitled"} | ${domain}`);
  parts.push(`URL: ${snapshot.url || "unknown"}`);

  // Visible sections with dwell + attention signal
  const sections = snapshot.visibleSections || [];
  if (sections.length > 0) {
    parts.push("");
    parts.push("Visible Sections:");
    sections.slice(0, 6).forEach((s) => {
      const dwellSec = ((s.dwellMs || 0) / 1000).toFixed(1);
      const pct = s.pctVisible || 0;
      const attention = s.dwellMs > 10000 ? " \u2190 user focused here" :
                        s.dwellMs > 4000  ? " \u2190 reading" : "";
      parts.push(`- ${s.label} (visible ${pct}%, dwelled ${dwellSec}s)${attention}`);
    });
  }

  // Active overlay / modal
  if (snapshot.activeOverlay) {
    parts.push("");
    const ov = snapshot.activeOverlay;
    parts.push(`Active Overlay: ${ov.id} (${ov.type})`);
    if (ov.content) parts.push(`  Preview: ${ov.content.slice(0, 120)}`);
  } else if (sections.length > 0) {
    parts.push("");
    parts.push("Active Overlay: None");
  }

  // Form state (only filled forms)
  const activeForms = (snapshot.formState || []).filter((f) => f.completeness > 0);
  if (activeForms.length > 0) {
    parts.push("");
    parts.push("Form State:");
    activeForms.slice(0, 3).forEach((form) => {
      const fieldSummary = form.fields
        .filter((f) => f.value && String(f.value).length > 0)
        .map((f) => `${f.name}="${String(f.value).slice(0, 40)}"`)
        .join(", ");
      if (fieldSummary) parts.push(`- ${form.name}: ${fieldSummary}`);
    });
  }

  // Click trail (last 5, most recent first)
  const clicks = snapshot.clickTrail || [];
  if (clicks.length > 0) {
    parts.push("");
    const displayClicks = clicks.slice(-5).reverse();
    parts.push(`Click Trail (last ${displayClicks.length}):`);
    const now = Date.now();
    displayClicks.forEach((c, i) => {
      const secsAgo = Math.round((now - (c.ts || now)) / 1000);
      const label = (c.text || c.selector || "element").slice(0, 60);
      parts.push(`${i + 1}. "${label}" (${secsAgo}s ago)`);
    });
  }

  // Time on page
  const timeOnPageMs = snapshot.currentPage?.timeOnPageMs ?? 0;
  if (timeOnPageMs > 0) {
    const secs = Math.round(timeOnPageMs / 1000);
    parts.push("");
    parts.push(`Time on Page: ${secs} seconds`);
  }

  // Navigation breadcrumb (previous pages)
  const navHistory = snapshot.navigationHistory || [];
  if (navHistory.length > 1) {
    const prevPages = navHistory
      .slice(-4, -1)
      .map((p) => p.title || p.path || "")
      .filter(Boolean);
    if (prevPages.length > 0) {
      parts.push(`Navigation: ${prevPages.join(" \u2192 ")} \u2192 current page`);
    }
  }

  // Wallet status
  const wp = snapshot.walletProviders || {};
  if (wp.phantomSolana) {
    const status = wp.phantomConnected && wp.phantomPublicKey
      ? `Phantom connected (${String(wp.phantomPublicKey).slice(0, 8)}...)`
      : "Phantom detected, not connected";
    parts.push("");
    parts.push(`Wallet: ${status}`);
  } else if (wp.braveSolana) {
    parts.push("");
    parts.push("Wallet: Brave Wallet detected");
  }

  // Raw visible text (compressed, after the structured data)
  const rawText = String(snapshot.text ?? "").slice(0, 5000);
  if (rawText) {
    parts.push("");
    parts.push(`Visible text:\n${rawText}`);
  }

  // Links
  const links = snapshot.links || [];
  if (links.length > 0) {
    const linkSample = links.slice(0, 10).map((l) => `${l.text} → ${l.href}`).join("\n");
    parts.push("");
    parts.push(`Key links (first 10):\n${linkSample}`);
  }

  return parts.join("\n");
};

const pageContextForBridge = () => {
  if (!lastSnapshot) return null;

  // If Resonant Context data is present, use the rich formatter
  const hasRichContext = lastSnapshot.visibleSections !== undefined
    || lastSnapshot.formState !== undefined
    || lastSnapshot.clickTrail !== undefined;

  if (hasRichContext) {
    return formatRichPageContext(lastSnapshot);
  }

  // Fallback: plain text
  const text = String(lastSnapshot.text ?? "").slice(0, 7000);
  return [
    `Title: ${lastSnapshot.title || "Untitled"}`,
    `URL: ${lastSnapshot.url || "unknown"}`,
    text ? `Visible text:\n${text}` : ""
  ].filter(Boolean).join("\n\n");
};

const bridgeChat = async () => {
  return bridgeRequest("/augmentor/chat", {
    method: "POST",
    body: {
      model: modelSelect.value,
      thinkingDepth: thinkingDepthSelect.value,
      pageContext: pageContextForBridge(),
      runtimeContext: attachments.length ? `Composer attachments:\n${attachments.map((item) => `- ${item.name}: ${item.content ?? item.summary}`).join("\n")}` : null,
      messages: messages
        .filter((message) => ["user", "assistant"].includes(message.role))
        .slice(-MAX_HISTORY_MESSAGES)
        .map((message) => ({ role: message.role, content: message.content }))
    }
  });
};

const parseSections = (body) => body.split("|").map((part) => part.trim()).filter(Boolean);

const runGoalCommand = async (body) => {
  const sections = parseSections(body);
  const mission = sections[0] ?? "";
  setActivity("tool-running", "Creating goal workspace", mission);
  const result = await bridgeRequest("/goals", {
    method: "POST",
    body: {
      mission,
      success: sections.filter((section) => /^success\s*:/i.test(section)).flatMap((section) => section.replace(/^success\s*:/i, "").split(/[,;]/).map((item) => item.trim()).filter(Boolean)),
      constraints: sections.filter((section) => /^constraints?\s*:/i.test(section)).flatMap((section) => section.replace(/^constraints?\s*:/i, "").split(/[,;]/).map((item) => item.trim()).filter(Boolean))
    }
  });
  await addMessage("system", `Goal workspace recorded: ${result.id}\n${result.mission}`);
};

// ── Item 14: Delegation Card renderer ─────────────────────────────────────────
const AGENT_ICONS = { hermes: "\uD83E\uDEB5", opencode: "\uD83D\uDCBB", engineer: "\u2699\uFE0F" };

const appendDelegationCard = (target, mission, result = {}) => {
  const icon = AGENT_ICONS[target] ?? "\uD83E\uDD16";
  const agentLabel = target.charAt(0).toUpperCase() + target.slice(1);
  const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  const card = document.createElement("article");
  card.className = "message delegation-card";

  const header = document.createElement("div");
  header.className = "delegation-header";

  const iconSpan = document.createElement("span");
  iconSpan.className = "delegation-icon";
  iconSpan.textContent = icon;

  const agentStrong = document.createElement("strong");
  agentStrong.className = "delegation-agent";
  agentStrong.textContent = agentLabel;

  const statusBadge = document.createElement("span");
  statusBadge.className = "delegation-status-badge";
  statusBadge.textContent = "Submitted";

  const timeEl = document.createElement("time");
  timeEl.textContent = timestamp;

  header.append(iconSpan, agentStrong, statusBadge, timeEl);

  const missionPara = document.createElement("p");
  missionPara.className = "delegation-mission";
  missionPara.textContent = mission;

  card.append(header, missionPara);

  if (result.id) {
    const idLine = document.createElement("small");
    idLine.className = "delegation-id";
    idLine.textContent = `ID: ${result.id}`;
    card.append(idLine);
  }

  transcript.append(card);
  transcript.scrollTop = transcript.scrollHeight;
};

const runDelegateCommand = async (body) => {
  const match = /^(engineer|hermes|opencode|open\s+code)\b\s*([\s\S]*)$/i.exec(body.trim());
  if (!match) {
    await addMessage("system", "Use `/delegate <engineer|hermes|opencode> <mission>`.");
    return;
  }
  const target = match[1].toLowerCase().replace(/\s+/g, "");
  const mission = match[2].trim();
  if (!mission) {
    await addMessage("system", "Provide a mission after the agent name. Example: `/delegate hermes research Solana token standards`.");
    return;
  }
  setActivity("tool-running", `Delegating to ${target}`, mission);
  let result = {};
  try {
    result = await bridgeRequest("/addons/delegate", {
      method: "POST",
      body: { target, mission }
    });
  } catch (error) {
    result = { error: error instanceof Error ? error.message : String(error) };
  }
  appendDelegationCard(target, mission, result);
  if (result.error) {
    await addMessage("system", `Bridge sync failed (delegation logged locally): ${result.error}`);
  }
  setActivity("completed", `Delegated to ${target}`, mission);
};

const runStatusCommand = async () => {
  setActivity("retrieving", "Checking ResonantOS status", "Providers, Living Archive, add-ons, goals");
  const result = await bridgeRequest("/status");
  const addonLines = result.addons.map((addon) => `- ${addon.name}: ${addon.available ? "available" : "missing"} · ${addon.mode}`).join("\n");
  await addMessage(
    "system",
    [
      "ResonantOS Browser status",
      `MiniMax credential: ${result.providers["shared-minimax"] ? "ready" : "missing"}`,
      `OpenAI credential: ${result.providers["shared-openai"] ? "ready" : "missing"}`,
      `Living Archive wiki pages: ${result.memory.wiki.pages}`,
      `Intake artifacts: ${result.memory.intake.artifacts}`,
      `Review requests/artifacts: ${result.memory.review.requests}/${result.memory.review.artifacts}`,
      "Add-ons:",
      addonLines,
      `Recorded goals/delegations: ${result.records.goals}/${result.records.delegations}`
    ].join("\n")
  );
};

const runMemorySearchCommand = async (body) => {
  const query = body.trim();
  setActivity("retrieving", "Searching Living Archive", query);
  const result = await bridgeRequest("/memory/search", {
    method: "POST",
    body: { query, limit: 5 }
  });
  await addMessage(
    "system",
    result.matches.length
      ? `Living Archive matches for "${result.query}":\n${result.matches.map((match) => `- ${match.title} (${match.path})\n  ${match.excerpt}`).join("\n")}`
      : `No Living Archive wiki match found for "${result.query}".`
  );
};

const runBrowserCommand = async (body) => {
  const match = /^(open|navigate|visit|go|search|find|news|research)\b\s*([\s\S]*)$/i.exec(body.trim());
  const target = (match?.[2] ?? body).trim();
  if (!target) {
    await addMessage("system", "Use `/browser open <url>` or `/browser search <query>`.");
    return;
  }
  const action = match?.[1]?.toLowerCase();
  if (["search", "find", "news", "research"].includes(action)) {
    await searchBrowser({ query: normalizeSearchQuery(target), action: action === "news" ? "news" : "search" });
    return;
  }
  await openBrowserUrl(target);
};

const respondToCommand = async (value) => {
  const slash = /^\/([a-z]+)(?:\s+([\s\S]*))?$/i.exec(value.trim());
  if (slash) {
    const name = slash[1].toLowerCase();
    const body = (slash[2] ?? "").trim();
    if (name === "goal") {
      await runGoalCommand(body);
      return;
    }
    if (name === "delegate") {
      await runDelegateCommand(body);
      return;
    }
    if (name === "status") {
      await runStatusCommand();
      return;
    }
    if (name === "memory") {
      await runMemorySearchCommand(body);
      return;
    }
    if (name === "browser") {
      await runBrowserCommand(body);
      return;
    }
    // ── Blackboard commands ─────────────────────────────────────
    if (name === "blackboard") {
      await openBlackboard();
      await addMessage("system", "Resonant Blackboard opened. Augmentor will display content there.");
      return;
    }
    if (name === "draw" || name === "diagram") {
      await openBlackboard();
      // Send a sample diagram if no JSON body provided
      let payload = { shapes: [] };
      if (body) {
        try { payload = JSON.parse(body); } catch { payload = { shapes: [] }; }
      }
      if (!payload.shapes?.length) {
        payload = {
          shapes: [
            { type: "rect",   x: 80,  y: 100, w: 160, h: 60, label: "Input",     color: "#24d18f" },
            { type: "arrow",  x1: 240, y1: 130, x2: 340, y2: 130, color: "#4db8ff" },
            { type: "rect",   x: 340, y: 100, w: 160, h: 60, label: "Process",   color: "#9b6dff" },
            { type: "arrow",  x1: 500, y1: 130, x2: 600, y2: 130, color: "#4db8ff" },
            { type: "rect",   x: 600, y: 100, w: 160, h: 60, label: "Output",    color: "#ffd166" },
          ]
        };
      }
      await sendToBlackboard("draw", payload);
      await addMessage("system", "Canvas diagram sent to Blackboard.");
      return;
    }
    if (name === "table") {
      await openBlackboard();
      let payload = { headers: [], rows: [], title: body || undefined };
      await sendToBlackboard("table", payload);
      await addMessage("system", "Table mode opened on Blackboard. Ask Augmentor to fill it with data.");
      return;
    }
    if (name === "doc") {
      await openBlackboard();
      const payload = { markdown: body || "# Document\n\nStart typing or ask Augmentor to write here." };
      await sendToBlackboard("document", payload);
      await addMessage("system", "Document rendered on Blackboard.");
      return;
    }
    if (name === "show") {
      await openBlackboard();
      const url = body || "";
      if (url) {
        await sendToBlackboard("embed", { url, title: url });
        await addMessage("system", `Embedding ${url} on Blackboard.`);
      } else {
        await addMessage("system", "Usage: /show <url>");
      }
      return;
    }
    if (name === "present") {
      await openBlackboard();
      let payload = { slides: [] };
      if (body) { try { payload = JSON.parse(body); } catch { payload = { slides: [] }; } }
      await sendToBlackboard("present", payload);
      await addMessage("system", "Presentation mode opened on Blackboard.");
      return;
    }
  }
  const typeIntent = parseTypeIntent(value);
  if (typeIntent) {
    await typeIntoActivePage(typeIntent);
    return;
  }
  const clickIntent = parseClickIntent(value);
  if (clickIntent) {
    await clickActivePageText(clickIntent);
    return;
  }
  const readPageIntent = parseReadPageIntent(value);
  if (readPageIntent) {
    await summarizeSnapshot();
    return;
  }
  const structuredEditIntent = parseStructuredPageEditIntent(value);
  if (structuredEditIntent) {
    await explainStructuredPageEditBoundary(structuredEditIntent.instruction);
    return;
  }
  const browserIntent = parseNaturalBrowserIntent(value);
  if (browserIntent) {
    await openBrowserUrl(browserIntent.target);
    return;
  }
  const searchIntent = parseNaturalSearchIntent(value);
  if (searchIntent) {
    await searchBrowser(searchIntent);
    return;
  }
  if (/^\/(read|context)\b/i.test(value) || /^\/(summari[sz]e)\b/i.test(value)) {
    await summarizeSnapshot();
    return;
  }
  if (/^\/(save|archive|intake)\b/i.test(value)) {
    await saveIntake();
    return;
  }
  // Natural language delegation: "delegate to hermes: research DeFi" or "delegate opencode: fix the bug"
  const delegateNatural = /\bdelegate\s+(?:to\s+)?(hermes|opencode|open\s+code|engineer)[:\s]+(.+)/i.exec(value);
  if (delegateNatural) {
    const natTarget = delegateNatural[1].toLowerCase().replace(/\s+/g, "");
    const natMission = delegateNatural[2].trim();
    if (natMission) {
      await runDelegateCommand(`${natTarget} ${natMission}`);
      return;
    }
  }

  // ── Resonator slash commands ────────────────────────────────────────────────
  if (/^\/highlight\s+/i.test(value)) {
    const txt = value.replace(/^\/highlight\s+/i, '').trim();
    if (txt) await sendResonatorCommand('resonator_highlight', { text: txt, duration: 4000 });
    return;
  }
  if (/^\/spotlight\s+/i.test(value)) {
    const txt = value.replace(/^\/spotlight\s+/i, '').trim();
    if (txt) await sendResonatorCommand('resonator_spotlight', { text: txt });
    return;
  }
  if (/^\/arrow\s+/i.test(value)) {
    const txt = value.replace(/^\/arrow\s+/i, '').trim();
    if (txt) await sendResonatorCommand('resonator_arrow', { text: txt });
    return;
  }
  if (/^\/guide$/i.test(value.trim()) || /^\/steps$/i.test(value.trim())) {
    await addMessage('system', 'Use /guide to ask Augmentor to walk you through the current page step by step. Try asking: "walk me through this page".');
    return;
  }
  if (/^\/clear-overlays$/i.test(value.trim()) || /^\/resonator-clear$/i.test(value.trim())) {
    await sendResonatorCommand('resonator_clear', {});
    await addMessage('system', 'Resonator overlays cleared.');
    return;
  }

  // ── Auto-read page context if message has page-related intent ─────────────
  const PAGE_INTENT_RE = /\b(screen|page|looking at|see|what is this|where am i|help me|this page|current|on here|showing|displayed|visible)\b/i;
  const needsPageContext = PAGE_INTENT_RE.test(value) && !(/^\//.test(value.trim()));
  const snapshotAge = lastSnapshot ? (Date.now() - (lastSnapshot._capturedAt || 0)) : Infinity;
  const snapshotStale = snapshotAge > 30000; // >30s old or never captured
  if (needsPageContext && (lastSnapshot === null || snapshotStale)) {
    setActivity('reading', 'Auto-reading page for context', '');
    const readResult = await readActivePage({ announce: false });
    if (readResult?.snapshot) {
      lastSnapshot = readResult.snapshot;
      lastSnapshot._capturedAt = Date.now();
    }
  }

  if (/wallet|phantom|seed phrase|private key/i.test(value)) {
    await addMessage("system", "Wallet actions are human-approval gated. I can discuss Phantom and browser context, but wallet connect, signing, seed phrases, private keys, and credential actions stay human-only.");
    setStatus("Approval gated");
    return;
  }

  setStatus("Thinking");
  setActivity("thinking", "Thinking", "Calling the selected model route");
  try {
    const result = await bridgeChat();
    setStatus("Writing");
    setActivity("writing", "Writing response", result.model || modelSelect.value);
    // Parse BLACKBOARD + RESONATOR markers from AI response
    const cleanReply = parseResonatorMarkersFromReply(parseBlackboardMarkersFromReply(result.reply));
    await addMessage("assistant", cleanReply, { usage: result.usage ?? { providerId: result.providerId, model: result.model } });
    await clearAttachments();
    setStatus("Ready");
  } catch (error) {
    setStatus("Provider failed");
    await addMessage("system", error instanceof Error ? error.message : String(error));
  } finally {
    clearActivitySoon();
  }
};

// ── Item 13: Voice Dictation ───────────────────────────────────────────────────
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let dictateActive = false;

const stopDictation = () => {
  dictateActive = false;
  dictateButton.classList.remove("dictate-active");
  dictateButton.title = "Dictate";
  if (recognition) {
    try { recognition.abort(); } catch (_) {}
    recognition = null;
  }
  if (statusLabel === "Listening") setStatus("Ready");
};

const startDictation = () => {
  if (!SpeechRecognitionAPI) {
    void addMessage("system", "Voice not supported in this browser");
    return;
  }
  if (dictateActive) {
    stopDictation();
    return;
  }
  recognition = new SpeechRecognitionAPI();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = "en-US";
  recognition.onstart = () => {
    dictateActive = true;
    dictateButton.classList.add("dictate-active");
    dictateButton.title = "Recording — click to stop";
    setStatus("Listening");
  };
  recognition.onresult = (event) => {
    const recognized = Array.from(event.results)
      .map((r) => r[0].transcript)
      .join(" ")
      .trim();
    if (recognized) {
      const current = commandInput.value;
      commandInput.value = current ? `${current} ${recognized}` : recognized;
      commandInput.focus();
    }
  };
  recognition.onerror = (event) => {
    if (event.error === "not-allowed") {
      void addMessage("system", "Microphone access denied. Please allow microphone permissions and try again.");
    } else if (event.error !== "no-speech" && event.error !== "aborted") {
      void addMessage("system", `Dictation error: ${event.error}`);
    }
    stopDictation();
  };
  recognition.onend = () => stopDictation();
  try {
    recognition.start();
  } catch (error) {
    void addMessage("system", `Could not start dictation: ${error.message}`);
    stopDictation();
  }
};

// ── Items 15 + 16: Theme Toggle & Settings Overlay ───────────────────────────
// Note: settingsOverlay + openSettings + closeSettings already declared in Item 2 block above.
// Here we add theme support and wire the new header buttons.
const themeToggleBtn = document.querySelector("#theme-toggle");
const themeToggleSettingsBtn = document.querySelector("#theme-toggle-settings");
const settingsToggleBtn = document.querySelector("#settings-toggle");
const copyMobileUrlBtn = document.querySelector("#copy-mobile-url");
const MOBILE_URL = "https://resonantclaw.com";

const applyTheme = (theme) => {
  document.documentElement.setAttribute("data-theme", theme);
  const icon = theme === "light" ? "\u2600\uFE0F" : "\uD83C\uDF19";
  const label = theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode";
  if (themeToggleBtn) themeToggleBtn.textContent = icon;
  if (themeToggleSettingsBtn) themeToggleSettingsBtn.textContent = label;
};

const toggleTheme = async () => {
  const current = document.documentElement.getAttribute("data-theme") ?? "dark";
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
  await chrome.storage?.local?.set?.({ [STORAGE_KEYS.theme]: next }).catch(() => undefined);
};

if (themeToggleBtn) themeToggleBtn.addEventListener("click", () => void toggleTheme());
if (themeToggleSettingsBtn) themeToggleSettingsBtn.addEventListener("click", () => void toggleTheme());
// Wire new header gear icon to the existing openSettings handler
if (settingsToggleBtn) settingsToggleBtn.addEventListener("click", () => void openSettings());

if (copyMobileUrlBtn) {
  copyMobileUrlBtn.addEventListener("click", async () => {
    await navigator.clipboard?.writeText?.(MOBILE_URL).catch(() => undefined);
    const original = copyMobileUrlBtn.textContent;
    copyMobileUrlBtn.textContent = "Copied!";
    copyMobileUrlBtn.classList.add("copied");
    window.setTimeout(() => {
      copyMobileUrlBtn.textContent = original;
      copyMobileUrlBtn.classList.remove("copied");
    }, 2000);
  });
}

// ────────────────────────────────────────────────────────────────────────
const hydrateChatSettings = async () => {
  const settings = await chrome.storage?.local?.get?.([
    STORAGE_KEYS.messages,
    STORAGE_KEYS.forks,
    STORAGE_KEYS.model,
    STORAGE_KEYS.thinkingDepth,
    STORAGE_KEYS.attachments,
    STORAGE_KEYS.theme
  ]).catch(() => ({}));
  // Apply saved theme (Item 15)
  const savedTheme = settings?.[STORAGE_KEYS.theme];
  applyTheme(savedTheme === "light" ? "light" : "dark");
  if (settings?.[STORAGE_KEYS.model] && [...modelSelect.options].some((option) => option.value === settings[STORAGE_KEYS.model])) {
    modelSelect.value = settings[STORAGE_KEYS.model];
  }
  if (settings?.[STORAGE_KEYS.thinkingDepth] && [...thinkingDepthSelect.options].some((option) => option.value === settings[STORAGE_KEYS.thinkingDepth])) {
    thinkingDepthSelect.value = settings[STORAGE_KEYS.thinkingDepth];
  }
  messages = Array.isArray(settings?.[STORAGE_KEYS.messages]) ? settings[STORAGE_KEYS.messages].filter((message) => ["user", "assistant", "system"].includes(message?.role)) : [];
  forks = Array.isArray(settings?.[STORAGE_KEYS.forks]) ? settings[STORAGE_KEYS.forks] : [];
  attachments = Array.isArray(settings?.[STORAGE_KEYS.attachments]) ? settings[STORAGE_KEYS.attachments] : [];
  renderMessages();
  renderAttachments();
  updateConnectionLine();
};

// ---------------------------------------------------------------------------
// Item 2: Settings overlay — load and save provider keys
// ---------------------------------------------------------------------------

const openSettings = async () => {
  if (!settingsOverlay) return;
  if (settingsStatus) settingsStatus.textContent = "";
  if (keyOpenAIInput) keyOpenAIInput.value = "";
  if (keyMiniMaxInput) keyMiniMaxInput.value = "";
  if (keyOpenAICurrent) keyOpenAICurrent.textContent = "";
  if (keyMiniMaxCurrent) keyMiniMaxCurrent.textContent = "";
  settingsOverlay.hidden = false;
  try {
    const result = await bridgeRequest("/providers/list");
    for (const provider of result.providers ?? []) {
      if (provider.id === "shared-openai" && keyOpenAICurrent) {
        keyOpenAICurrent.textContent = provider.maskedKey ? `current: ${provider.maskedKey}` : "not set";
      }
      if (provider.id === "shared-minimax" && keyMiniMaxCurrent) {
        keyMiniMaxCurrent.textContent = provider.maskedKey ? `current: ${provider.maskedKey}` : "not set";
      }
    }
  } catch (error) {
    if (settingsStatus) settingsStatus.textContent = `Load failed: ${error instanceof Error ? error.message : String(error)}`;
  }
};

const closeSettings = () => {
  if (!settingsOverlay) return;
  settingsOverlay.hidden = true;
  if (keyOpenAIInput) keyOpenAIInput.value = "";
  if (keyMiniMaxInput) keyMiniMaxInput.value = "";
};

const saveSettings = async () => {
  if (!settingsSave) return;
  settingsSave.disabled = true;
  if (settingsStatus) settingsStatus.textContent = "Saving…";
  const providers = {};
  const openAIKey = keyOpenAIInput?.value.trim() ?? "";
  const miniMaxKey = keyMiniMaxInput?.value.trim() ?? "";
  if (openAIKey) providers["shared-openai"] = openAIKey;
  if (miniMaxKey) providers["shared-minimax"] = miniMaxKey;
  if (!Object.keys(providers).length) {
    if (settingsStatus) settingsStatus.textContent = "No changes to save.";
    settingsSave.disabled = false;
    return;
  }
  try {
    await bridgeRequest("/providers/save", { method: "POST", body: { providers } });
    if (settingsStatus) settingsStatus.textContent = "Saved ✓";
    if (keyOpenAIInput) keyOpenAIInput.value = "";
    if (keyMiniMaxInput) keyMiniMaxInput.value = "";
    const refreshed = await bridgeRequest("/providers/list");
    for (const provider of refreshed.providers ?? []) {
      if (provider.id === "shared-openai" && keyOpenAICurrent) {
        keyOpenAICurrent.textContent = provider.maskedKey ? `current: ${provider.maskedKey}` : "not set";
      }
      if (provider.id === "shared-minimax" && keyMiniMaxCurrent) {
        keyMiniMaxCurrent.textContent = provider.maskedKey ? `current: ${provider.maskedKey}` : "not set";
      }
    }
    setTimeout(() => { if (settingsStatus) settingsStatus.textContent = ""; }, 3000);
  } catch (error) {
    if (settingsStatus) settingsStatus.textContent = `Save failed: ${error instanceof Error ? error.message : String(error)}`;
  } finally {
    settingsSave.disabled = false;
  }
};

if (settingsOpenButton) settingsOpenButton.addEventListener("click", () => void openSettings());
if (settingsClose) settingsClose.addEventListener("click", closeSettings);
if (settingsSave) settingsSave.addEventListener("click", () => void saveSettings());
if (settingsOverlay) settingsOverlay.addEventListener("click", (event) => {
  if (event.target === settingsOverlay) closeSettings();
});

// ---------------------------------------------------------------------------
// Item 3: Wallet banner — show state based on page snapshot
// ---------------------------------------------------------------------------

const updateWalletBanner = (snapshot) => {
  if (!snapshot) {
    walletBanner.hidden = true;
    return;
  }
  const { walletProviders } = snapshot;
  const isPhantom = Boolean(walletProviders?.phantomSolana);
  const isConnected = Boolean(walletProviders?.phantomConnected);
  const publicKey = walletProviders?.phantomPublicKey ?? null;

  walletBanner.className = "wallet-banner";

  if (!isPhantom) {
    walletBanner.classList.add("wallet-missing");
    walletBanner.hidden = false;
    walletBanner.innerHTML = [
      '<span class="wallet-banner-icon">\uD83D\uDC7B</span>',
      '<span>Phantom wallet not detected. <a href="https://chromewebstore.google.com/detail/phantom/bfnaelmomeimhlpmgjnjophhpkkoljpa" target="_blank" rel="noopener">Install Phantom</a></span>',
    ].join("");
    return;
  }

  if (isConnected && publicKey) {
    // Sanitize publicKey — use textContent, NEVER innerHTML with user-controlled data
    const safeKey = String(publicKey).replace(/[^a-zA-Z0-9]/g, "");
    const short = safeKey.length >= 8 ? `${safeKey.slice(0, 4)}\u2026${safeKey.slice(-4)}` : safeKey;
    walletBanner.classList.add("wallet-connected");
    walletBanner.hidden = false;
    walletBanner.replaceChildren();
    const icon = document.createElement("span");
    icon.className = "wallet-banner-icon";
    icon.textContent = "\u2705";
    const label = document.createElement("span");
    label.textContent = `Wallet connected: ${short}`;
    walletBanner.append(icon, label);
    return;
  }

  // Phantom detected but not connected
  walletBanner.classList.add("wallet-detected");
  walletBanner.hidden = false;
  walletBanner.innerHTML = [
    '<span class="wallet-banner-icon">\uD83D\uDC7B</span>',
    '<span>Phantom detected. Connect your wallet on the current page.</span>',
  ].join("");
};

attachFileButton.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => void attachFiles(fileInput.files));
readButton.addEventListener("click", () => void readActivePage());
saveIntakeButton.addEventListener("click", () => void saveIntake());
modelSelect.addEventListener("change", () => void persistChatState().then(updateConnectionLine));
thinkingDepthSelect.addEventListener("change", () => void persistChatState());
dictateButton.addEventListener("click", () => startDictation());

commandForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (turnBusy) {
    return;
  }
  const value = commandInput.value.trim();
  if (!value) {
    return;
  }
  setTurnBusy(true);
  try {
    await addMessage("user", value);
    commandInput.value = "";
    await respondToCommand(value);
  } finally {
    setTurnBusy(false);
    if (statusLabel === "Ready") {
      clearActivitySoon();
    }
  }
});

// ── Update-banner check (once per session) ───────────────────────────────────

const UPDATE_BANNER_KEY = "augmentorUpdateBannerShown";

const checkForUpdateOnce = async () => {
  // Guard: only show once per session (not per load — storage is session-persistent).
  const seen = await chrome.storage?.session?.get?.([UPDATE_BANNER_KEY]).catch(() => ({}));
  if (seen?.[UPDATE_BANNER_KEY]) return;

  try {
    const result = await bridgeRequest("/update/check");
    if (result?.updateAvailable) {
      const banner = document.createElement("div");
      banner.id = "update-banner";
      banner.className = "update-banner";
      banner.setAttribute("role", "status");
      banner.setAttribute("aria-live", "polite");
      // Build update banner safely — no innerHTML with external data
      const safeVersion = String(result.latestVersion).replace(/[^0-9.]/g, "");
      const safeUrl = String(result.downloadUrl).startsWith("https://") ? result.downloadUrl : "#";
      const msgSpan = document.createElement("span");
      msgSpan.textContent = `ResonantOS v${safeVersion} available. `;
      const link = document.createElement("a");
      link.href = safeUrl;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Update instructions";
      msgSpan.append(link, ".");
      const dismissBtn = document.createElement("button");
      dismissBtn.type = "button";
      dismissBtn.className = "update-banner-dismiss";
      dismissBtn.setAttribute("aria-label", "Dismiss update notice");
      dismissBtn.textContent = "\u00d7";
      dismissBtn.addEventListener("click", () => banner.remove());
      banner.append(msgSpan, dismissBtn);
      document.querySelector(".chat-shell")?.prepend(banner);
    }
    // Mark shown so we don't re-check until extension reload.
    await chrome.storage?.session?.set?.({ [UPDATE_BANNER_KEY]: true }).catch(() => undefined);
  } catch {
    // Update check failures are silent — don't interrupt the user.
  }
};

hydrateChatSettings()
  .then(() => refreshTabContext())
  .then(() => void checkForUpdateOnce())
  .catch((error) => {
    setStatus("Context failed");
    void addMessage("system", `I could not read the active tab context: ${String(error)}`);
  });

// ── Blackboard → Augmentor two-way bridge listener ────────────────────────────
// Listens for blackboard content delivered via chrome.storage.session.
// Background stores the payload under "blackboardToPanel" when the blackboard
// tab clicks "Send to Augmentor".

let _lastBlackboardTs = 0;

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'session') return;
  const change = changes.blackboardToPanel;
  if (!change?.newValue) return;
  const record = change.newValue;
  // Deduplicate: ignore if same timestamp as last handled
  if (record._ts && record._ts === _lastBlackboardTs) return;
  _lastBlackboardTs = record._ts || 0;

  const label = record.label || 'Blackboard content';
  const mode = record.mode || 'unknown';
  const content = record.content || '';

  if (!content) return;

  if (record.type === 'image') {
    // Store as an attachment-like context string referencing the image
    const ctx = `[Blackboard image received: ${label}. The user has sent a canvas diagram from the Blackboard. Analyze and discuss the visual content.]`;
    attachments = [...attachments, {
      id: `bb-${Date.now()}`,
      name: `Blackboard: ${label}`,
      size: content.length,
      type: 'image/png',
      summary: `Blackboard canvas diagram (${mode} mode)`,
      content: ctx,
    }];
    renderAttachments();
    void persistChatState();
    void addMessage('system', `Blackboard content received: ${label} (canvas diagram). It is now attached as context for your next message to Augmentor.`);
  } else {
    // Text content — inject as attachment
    attachments = [...attachments, {
      id: `bb-${Date.now()}`,
      name: `Blackboard: ${label}`,
      size: content.length,
      type: 'text/plain',
      summary: `Blackboard ${mode} content`,
      content: content.slice(0, 8000),
    }];
    renderAttachments();
    void persistChatState();
    void addMessage('system', `Blackboard content received from ${label}. It is now attached as context. Type your message to Augmentor to discuss this content.`);
  }

  setStatus('Blackboard received');
});

// ===========================================================================
// Tribes & Bounties Panels
// ===========================================================================

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const TRIBES_SECTION = document.getElementById("tribes-section");
const TRIBES_BODY = document.getElementById("tribes-body");
const BOUNTIES_SECTION = document.getElementById("bounties-section");
const BOUNTIES_BODY = document.getElementById("bounties-body");

/** Return connected wallet address or null */
const getWalletAddr = () => getWalletState()?.address ?? null;

/** Build a safe text node and return it (no innerHTML) */
const safeText = (value) => document.createTextNode(String(value ?? ""));

/** Create an element, optionally set className and textContent */
const el = (tag, { className, text } = {}) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
};

const focusBadgeClass = (focus) => {
  const map = { engineering: "", creative: "focus-creative", research: "focus-research",
    community: "focus-community", economy: "focus-economy", technical: "focus-technical" };
  return map[focus] ?? "";
};

const statusBadgeClass = (status) => {
  const map = { open: "status-open", claimed: "status-claimed", complete: "status-complete" };
  return map[status] ?? "";
};

const statusEmoji = (status) => {
  if (status === "open") return "\u{1F7E2}";
  if (status === "claimed") return "\u{1F7E1}";
  if (status === "complete") return "\u2705";
  return "";
};

// ---------------------------------------------------------------------------
// Tribes
// ---------------------------------------------------------------------------

let _tribesData = [];
let _tribeCreateFormVisible = false;

const refreshTribes = async () => {
  if (!TRIBES_BODY) return;
  try {
    const result = await bridgeRequest("/tribes");
    _tribesData = result.tribes ?? [];
    renderTribes();
  } catch (error) {
    TRIBES_BODY.replaceChildren();
    const errEl = el("p", { className: "panel-section-error" });
    errEl.textContent = `Tribes unavailable: ${String(error.message ?? error)}`;
    TRIBES_BODY.append(errEl);
  }
};

const renderTribes = () => {
  if (!TRIBES_BODY) return;
  TRIBES_BODY.replaceChildren();

  const walletAddr = getWalletAddr();

  if (!_tribesData.length) {
    TRIBES_BODY.append(el("p", { className: "panel-section-empty", text: "No tribes yet. Create the first one!" }));
  } else {
    for (const tribe of _tribesData) {
      TRIBES_BODY.append(renderTribeCard(tribe, walletAddr));
    }
  }

  // Add button
  const addBtn = el("button", { className: "section-add-btn", text: "+ Create Tribe" });
  addBtn.type = "button";
  addBtn.addEventListener("click", () => {
    _tribeCreateFormVisible = !_tribeCreateFormVisible;
    renderTribes();
  });
  TRIBES_BODY.append(addBtn);

  // Create form
  if (_tribeCreateFormVisible) {
    TRIBES_BODY.append(buildTribeCreateForm());
  }
};

const renderTribeCard = (tribe, walletAddress) => {
  const card = el("div", { className: "tribe-card" });

  // Header row: name + focus badge
  const header = el("div", { className: "tribe-card-header" });
  const nameEl = el("p", { className: "tribe-card-name", text: tribe.name });
  header.append(nameEl);

  const focusBadge = el("span",
    { className: `tribe-focus-badge ${focusBadgeClass(tribe.focus)}`, text: tribe.focus || "general" }
  );
  header.append(focusBadge);
  card.append(header);

  // Description
  if (tribe.description) {
    card.append(el("p", { className: "tribe-card-desc", text: tribe.description }));
  }

  // Member count
  const memberCount = Array.isArray(tribe.members) ? tribe.members.length : 0;
  card.append(el("span", { className: "tribe-card-meta", text: `${memberCount} member${memberCount !== 1 ? "s" : ""}` }));

  // Action buttons
  const isMember = walletAddress && Array.isArray(tribe.members) && tribe.members.includes(walletAddress);
  const actionsRow = el("div", { className: "tribe-card-actions" });

  if (walletAddress) {
    if (isMember) {
      const leaveBtn = el("button", { className: "tribe-action-btn leave-btn", text: "Leave" });
      leaveBtn.type = "button";
      leaveBtn.addEventListener("click", async () => {
        leaveBtn.disabled = true;
        try {
          await bridgeRequest("/tribes/leave", {
            method: "POST",
            body: { tribeId: tribe.id, walletAddress },
          });
          await refreshTribes();
        } catch (error) {
          leaveBtn.disabled = false;
          leaveBtn.textContent = "Error";
          window.setTimeout(() => { leaveBtn.textContent = "Leave"; leaveBtn.disabled = false; }, 2000);
        }
      });
      actionsRow.append(leaveBtn);
    } else {
      const joinBtn = el("button", { className: "tribe-action-btn", text: "Join" });
      joinBtn.type = "button";
      joinBtn.addEventListener("click", async () => {
        joinBtn.disabled = true;
        try {
          await bridgeRequest("/tribes/join", {
            method: "POST",
            body: { tribeId: tribe.id, walletAddress },
          });
          await refreshTribes();
        } catch (error) {
          joinBtn.disabled = false;
          joinBtn.textContent = "Error";
          window.setTimeout(() => { joinBtn.textContent = "Join"; joinBtn.disabled = false; }, 2000);
        }
      });
      actionsRow.append(joinBtn);
    }
  } else {
    const noWallet = el("span", { className: "tribe-card-meta", text: "Connect wallet to join" });
    actionsRow.append(noWallet);
  }

  card.append(actionsRow);
  return card;
};

const buildTribeCreateForm = () => {
  const form = el("div", { className: "tribe-create-form" });

  const nameInput = el("input");
  nameInput.type = "text";
  nameInput.placeholder = "Tribe name";
  nameInput.maxLength = 80;

  const descInput = el("textarea");
  descInput.placeholder = "Description";
  descInput.rows = 2;
  descInput.maxLength = 320;

  const focusSelect = document.createElement("select");
  for (const opt of ["engineering", "creative", "research", "community", "economy", "technical"]) {
    const option = document.createElement("option");
    option.value = opt;
    option.textContent = opt;
    focusSelect.append(option);
  }

  const actionsRow = el("div", { className: "create-form-actions" });

  const submitBtn = el("button", { className: "create-form-submit", text: "Create" });
  submitBtn.type = "button";
  submitBtn.addEventListener("click", async () => {
    const name = nameInput.value.trim();
    if (!name) { nameInput.focus(); return; }
    submitBtn.disabled = true;
    submitBtn.textContent = "Creating\u2026";
    try {
      const walletAddr = getWalletAddr();
      await bridgeRequest("/tribes", {
        method: "POST",
        body: {
          name,
          description: descInput.value.trim(),
          focus: focusSelect.value,
          createdBy: walletAddr ?? "anonymous",
        },
      });
      _tribeCreateFormVisible = false;
      await refreshTribes();
    } catch (error) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Create";
      nameInput.setCustomValidity(String(error.message ?? error));
      nameInput.reportValidity();
    }
  });

  const cancelBtn = el("button", { className: "create-form-cancel", text: "Cancel" });
  cancelBtn.type = "button";
  cancelBtn.addEventListener("click", () => {
    _tribeCreateFormVisible = false;
    renderTribes();
  });

  actionsRow.append(submitBtn, cancelBtn);
  form.append(nameInput, descInput, focusSelect, actionsRow);
  return form;
};

// ---------------------------------------------------------------------------
// Bounties
// ---------------------------------------------------------------------------

let _bountiesData = [];
let _bountyCreateFormVisible = false;

const refreshBounties = async () => {
  if (!BOUNTIES_BODY) return;
  try {
    const result = await bridgeRequest("/bounties");
    _bountiesData = result.bounties ?? [];
    renderBounties();
  } catch (error) {
    BOUNTIES_BODY.replaceChildren();
    const errEl = el("p", { className: "panel-section-error" });
    errEl.textContent = `Bounties unavailable: ${String(error.message ?? error)}`;
    BOUNTIES_BODY.append(errEl);
  }
};

const renderBounties = () => {
  if (!BOUNTIES_BODY) return;
  BOUNTIES_BODY.replaceChildren();

  const walletAddr = getWalletAddr();

  if (!_bountiesData.length) {
    BOUNTIES_BODY.append(el("p", { className: "panel-section-empty", text: "No bounties yet. Post the first one!" }));
  } else {
    for (const bounty of _bountiesData) {
      BOUNTIES_BODY.append(renderBountyCard(bounty, walletAddr));
    }
  }

  // Add button
  const addBtn = el("button", { className: "section-add-btn", text: "+ Post Bounty" });
  addBtn.type = "button";
  addBtn.addEventListener("click", () => {
    _bountyCreateFormVisible = !_bountyCreateFormVisible;
    renderBounties();
  });
  BOUNTIES_BODY.append(addBtn);

  // Create form
  if (_bountyCreateFormVisible) {
    BOUNTIES_BODY.append(buildBountyCreateForm());
  }
};

const renderBountyCard = (bounty, walletAddress) => {
  const card = el("div", { className: "bounty-card" });

  // Header: title + status badge
  const header = el("div", { className: "bounty-card-header" });
  const titleEl = el("p", { className: "bounty-card-title", text: bounty.title });
  header.append(titleEl);

  const statusLabel = `${statusEmoji(bounty.status)} ${bounty.status || "open"}`;
  const statusBadge = el("span",
    { className: `bounty-status ${statusBadgeClass(bounty.status)}`, text: statusLabel }
  );
  header.append(statusBadge);
  card.append(header);

  // Description
  if (bounty.description) {
    card.append(el("p", { className: "bounty-card-desc", text: bounty.description }));
  }

  // Reward
  const tokenClass = String(bounty.rewardToken ?? "RES").toUpperCase() === "RCT" ? "token-rct" : "";
  const rewardEl = el("span",
    { className: `bounty-reward ${tokenClass}`, text: `${bounty.reward} $${bounty.rewardToken ?? "RES"}` }
  );
  card.append(rewardEl);

  // Actions
  const actionsRow = el("div", { className: "bounty-card-actions" });
  const isOpen = bounty.status === "open";
  const isClaimed = bounty.status === "claimed";
  const isComplete = bounty.status === "complete";
  const isMyBounty = walletAddress && bounty.claimedBy === walletAddress;

  if (walletAddress && isOpen) {
    const claimBtn = el("button", { className: "bounty-action-btn", text: "Claim" });
    claimBtn.type = "button";
    claimBtn.addEventListener("click", async () => {
      claimBtn.disabled = true;
      try {
        await bridgeRequest("/bounties/claim", {
          method: "POST",
          body: { bountyId: bounty.id, walletAddress },
        });
        await refreshBounties();
      } catch (error) {
        claimBtn.disabled = false;
        claimBtn.textContent = "Error";
        window.setTimeout(() => { claimBtn.textContent = "Claim"; claimBtn.disabled = false; }, 2000);
      }
    });
    actionsRow.append(claimBtn);
  } else if (isClaimed && isMyBounty) {
    const completeBtn = el("button", { className: "bounty-action-btn", text: "Mark Complete" });
    completeBtn.type = "button";
    completeBtn.addEventListener("click", async () => {
      completeBtn.disabled = true;
      try {
        await bridgeRequest("/bounties/complete", {
          method: "POST",
          body: { bountyId: bounty.id },
        });
        await refreshBounties();
      } catch (error) {
        completeBtn.disabled = false;
        completeBtn.textContent = "Error";
        window.setTimeout(() => { completeBtn.textContent = "Mark Complete"; completeBtn.disabled = false; }, 2000);
      }
    });
    actionsRow.append(completeBtn);
  } else if (!walletAddress) {
    actionsRow.append(el("span", { className: "tribe-card-meta", text: "Connect wallet to claim" }));
  } else if (isClaimed) {
    actionsRow.append(el("span", { className: "tribe-card-meta", text: `Claimed by ${bounty.claimedBy?.slice(0, 6) ?? "?"}\u2026` }));
  } else if (isComplete) {
    actionsRow.append(el("span", { className: "tribe-card-meta", text: "\u2705 Completed" }));
  }

  if (actionsRow.childElementCount) card.append(actionsRow);
  return card;
};

const buildBountyCreateForm = () => {
  const form = el("div", { className: "bounty-create-form" });

  const titleInput = el("input");
  titleInput.type = "text";
  titleInput.placeholder = "Bounty title";
  titleInput.maxLength = 160;

  const descInput = el("textarea");
  descInput.placeholder = "Description";
  descInput.rows = 2;
  descInput.maxLength = 600;

  const rewardRow = el("div");
  rewardRow.style.cssText = "display:flex;gap:5px;";

  const rewardInput = el("input");
  rewardInput.type = "number";
  rewardInput.placeholder = "Reward amount";
  rewardInput.min = "1";
  rewardInput.style.flex = "2";

  const tokenSelect = document.createElement("select");
  tokenSelect.style.flex = "1";
  for (const token of ["RES", "RCT"]) {
    const option = document.createElement("option");
    option.value = token;
    option.textContent = `$${token}`;
    tokenSelect.append(option);
  }

  rewardRow.append(rewardInput, tokenSelect);

  const actionsRow = el("div", { className: "create-form-actions" });

  const submitBtn = el("button", { className: "create-form-submit", text: "Post Bounty" });
  submitBtn.type = "button";
  submitBtn.addEventListener("click", async () => {
    const title = titleInput.value.trim();
    const reward = Number(rewardInput.value);
    if (!title) { titleInput.focus(); return; }
    if (!reward || reward <= 0) { rewardInput.focus(); return; }
    submitBtn.disabled = true;
    submitBtn.textContent = "Posting\u2026";
    try {
      const walletAddr = getWalletAddr();
      await bridgeRequest("/bounties", {
        method: "POST",
        body: {
          title,
          description: descInput.value.trim(),
          reward,
          rewardToken: tokenSelect.value,
          createdBy: walletAddr ?? "anonymous",
        },
      });
      _bountyCreateFormVisible = false;
      await refreshBounties();
    } catch (error) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Post Bounty";
      titleInput.setCustomValidity(String(error.message ?? error));
      titleInput.reportValidity();
    }
  });

  const cancelBtn = el("button", { className: "create-form-cancel", text: "Cancel" });
  cancelBtn.type = "button";
  cancelBtn.addEventListener("click", () => {
    _bountyCreateFormVisible = false;
    renderBounties();
  });

  actionsRow.append(submitBtn, cancelBtn);
  form.append(titleInput, descInput, rewardRow, actionsRow);
  return form;
};

// ---------------------------------------------------------------------------
// Wire up toggle listeners — load data when section opened
// ---------------------------------------------------------------------------

if (TRIBES_SECTION) {
  TRIBES_SECTION.addEventListener("toggle", () => {
    if (TRIBES_SECTION.open) {
      void refreshTribes();
    }
  });
}

if (BOUNTIES_SECTION) {
  BOUNTIES_SECTION.addEventListener("toggle", () => {
    if (BOUNTIES_SECTION.open) {
      void refreshBounties();
    }
  });
}

// ===========================================================================
// Symbiotic Wallet Panel
// ===========================================================================

const WALLET_NETWORK_KEY = "resonantos_wallet_network";

let walletPanelNetwork = "devnet";

const loadWalletNetwork = async () => {
  try {
    const stored = await chrome.storage?.local?.get?.([WALLET_NETWORK_KEY]).catch(() => ({}));
    if (stored?.[WALLET_NETWORK_KEY]) {
      walletPanelNetwork = stored[WALLET_NETWORK_KEY];
    }
  } catch {
    // defaults to devnet
  }
};

const saveWalletNetwork = async (network) => {
  walletPanelNetwork = network;
  try {
    await chrome.storage?.local?.set?.({ [WALLET_NETWORK_KEY]: network }).catch(() => undefined);
  } catch { /* ignore */ }
};

const refreshWalletPanel = async () => {
  const body = document.getElementById("wallet-body");
  if (!body) return;

  const state = getWalletState ? getWalletState() : null;
  const address = state?.address ?? null;

  if (!address) {
    renderWalletPanel(null, null);
    return;
  }

  try {
    const result = await bridgeRequest(
      `/wallet/balances?network=${encodeURIComponent(walletPanelNetwork)}&address=${encodeURIComponent(address)}`
    );
    renderWalletPanel(address, result);
  } catch (err) {
    renderWalletPanel(address, null, String(err?.message ?? err));
  }
};

const renderWalletPanel = (address, data, errorMsg = null) => {
  const body = document.getElementById("wallet-body");
  if (!body) return;
  body.replaceChildren();

  // Network toggle
  const networkRow = document.createElement("div");
  networkRow.className = "wallet-network-toggle";
  for (const net of ["devnet", "mainnet-beta"]) {
    const btn = document.createElement("button");
    btn.type = "button";
    const isActive = walletPanelNetwork === net;
    btn.className = "wallet-net-btn" + (isActive ? " wallet-net-btn-active" : "");
    btn.textContent = net === "devnet" ? "Devnet" : "Mainnet";
    btn.addEventListener("click", async () => {
      await saveWalletNetwork(net);
      await refreshWalletPanel();
    });
    networkRow.append(btn);
  }
  body.append(networkRow);

  if (!address) {
    const msg = document.createElement("p");
    msg.className = "wallet-placeholder";
    msg.textContent = "Connect wallet first";
    body.append(msg);
    return;
  }

  // Address row (monospace, truncated, copy button)
  const addrRow = document.createElement("div");
  addrRow.className = "wallet-address";
  const truncated = address.length > 12
    ? `${address.slice(0, 4)}\u2026${address.slice(-4)}`
    : address;
  const addrSpan = document.createElement("span");
  addrSpan.textContent = truncated;
  addrSpan.title = address;
  addrSpan.style.flex = "1";
  addrSpan.style.overflow = "hidden";
  addrSpan.style.textOverflow = "ellipsis";
  addrSpan.style.whiteSpace = "nowrap";
  const copyBtn = document.createElement("button");
  copyBtn.type = "button";
  copyBtn.className = "wallet-copy-btn";
  copyBtn.title = "Copy address";
  copyBtn.textContent = "\u2398"; // ⎘
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(address).catch(() => {});
    copyBtn.textContent = "\u2713"; // ✓
    setTimeout(() => { copyBtn.textContent = "\u2398"; }, 1500);
  });
  addrRow.append(addrSpan, copyBtn);
  body.append(addrRow);

  // Error state
  if (errorMsg) {
    const errEl = document.createElement("p");
    errEl.className = "wallet-error";
    errEl.textContent = errorMsg;
    body.append(errEl);
    return;
  }

  // Balance rows: SOL, $RCT, $RES
  if (data) {
    const balances = [
      ["SOL",  typeof data.sol === "number" ? data.sol.toFixed(4) : "\u2014"],
      ["$RCT", typeof data.rct === "number" ? data.rct.toLocaleString() : "\u2014"],
      ["$RES", typeof data.res === "number" ? data.res.toLocaleString() : "\u2014"],
    ];
    for (const [label, value] of balances) {
      const row = document.createElement("div");
      row.className = "wallet-balance-row";
      const lbl = document.createElement("span");
      lbl.className = "wallet-balance-label";
      lbl.textContent = label;
      const amt = document.createElement("span");
      amt.className = "wallet-balance-amount";
      amt.textContent = value; // safe: numeric strings only
      row.append(lbl, amt);
      body.append(row);
    }
  }

  // Action buttons row
  const btnRow = document.createElement("div");
  btnRow.className = "wallet-action-row";

  // Send — human-gated
  const sendBtn = document.createElement("button");
  sendBtn.type = "button";
  sendBtn.className = "wallet-action-btn";
  sendBtn.textContent = "Send";
  sendBtn.addEventListener("click", () => {
    const existing = body.querySelector(".wallet-gate-msg");
    if (existing) { existing.remove(); return; }
    const msg = document.createElement("p");
    msg.className = "wallet-gate-msg";
    msg.textContent = "Human approval required \u2014 use Phantom directly to send funds.";
    body.append(msg);
  });

  // Receive — show address for copy/QR
  const receiveBtn = document.createElement("button");
  receiveBtn.type = "button";
  receiveBtn.className = "wallet-action-btn";
  receiveBtn.textContent = "Receive";
  receiveBtn.addEventListener("click", () => {
    const existing = body.querySelector(".wallet-receive-msg");
    if (existing) { existing.remove(); return; }
    const msg = document.createElement("p");
    msg.className = "wallet-receive-msg";
    msg.textContent = address; // full address — textContent, never innerHTML
    body.append(msg);
  });

  btnRow.append(sendBtn, receiveBtn);

  // Airdrop — devnet only
  if (walletPanelNetwork === "devnet") {
    const airdropBtn = document.createElement("button");
    airdropBtn.type = "button";
    airdropBtn.className = "wallet-action-btn wallet-airdrop-btn";
    airdropBtn.textContent = "Airdrop 1 SOL";
    airdropBtn.addEventListener("click", async () => {
      airdropBtn.disabled = true;
      airdropBtn.textContent = "Requesting\u2026";
      try {
        await bridgeRequest("/wallet/airdrop", {
          method: "POST",
          body: { address, network: "devnet" },
        });
        airdropBtn.textContent = "Sent!";
        setTimeout(() => void refreshWalletPanel(), 2500);
      } catch (err) {
        airdropBtn.textContent = "Failed";
        console.warn("[wallet] airdrop error:", err);
        setTimeout(() => {
          airdropBtn.disabled = false;
          airdropBtn.textContent = "Airdrop 1 SOL";
        }, 3000);
      }
    });
    btnRow.append(airdropBtn);
  }

  body.append(btnRow);
};

// Wire wallet section toggle
const WALLET_SECTION_EL = document.getElementById("wallet-section");
if (WALLET_SECTION_EL) {
  WALLET_SECTION_EL.addEventListener("toggle", () => {
    if (WALLET_SECTION_EL.open) {
      void loadWalletNetwork().then(() => refreshWalletPanel());
    }
  });
}

// ===========================================================================
// Protocol Store Panel
// ===========================================================================

const STORE_SECTION = document.getElementById("store-section");
const STORE_BODY = document.getElementById("store-body");
const PROTOCOL_GRID = document.getElementById("protocol-grid");
const STORE_SEARCH_INPUT = document.getElementById("store-search");
const STORE_CATEGORY_FILTERS = document.getElementById("store-category-filters");
const STORE_SUBMIT_BTN = document.getElementById("store-submit-btn");
const STORE_SUBMIT_FORM = document.getElementById("store-submit-form");
const STORE_SUBMIT_CONFIRM = document.getElementById("store-submit-confirm");
const STORE_SUBMIT_CANCEL = document.getElementById("store-submit-cancel");
const TAB_ALL = document.getElementById("tab-all");
const TAB_OWNED = document.getElementById("tab-owned");

let _storeProtocols = [];
let _storeCategory = "";
let _storeTab = "all"; // "all" | "owned"

const categoryStars = (rating) => {
  if (!rating) return "\u2605\u2606\u2606\u2606\u2606";
  const full = Math.round(rating);
  return "\u2605".repeat(full) + "\u2606".repeat(Math.max(0, 5 - full));
};

const renderProtocolCard = (proto) => {
  const card = el("div", { className: "protocol-card" });

  // Header row: name + category badge
  const header = el("div", { className: "protocol-card-header" });
  const nameEl = el("p", { className: "protocol-card-name", text: proto.name ?? "Unnamed" });
  const catEl = el("span", { className: "protocol-category" });
  catEl.dataset.cat = proto.category ?? "Tool";
  catEl.textContent = proto.category ?? "Tool";
  header.append(nameEl, catEl);

  // Description
  const desc = el("p", { className: "protocol-card-desc", text: proto.description ?? "" });

  // Footer: meta + install button
  const footer = el("div", { className: "protocol-card-footer" });
  const meta = el("div", { className: "protocol-meta" });

  const priceEl = el("span", { className: "protocol-price" + (proto.price === 0 ? " free" : "") });
  priceEl.textContent = proto.price === 0 ? "Free" : `${proto.price} ${proto.priceToken ?? "RES"}`;

  const ratingEl = el("span", { className: "protocol-rating" });
  ratingEl.textContent = categoryStars(proto.rating) + (proto.rating ? ` ${Number(proto.rating).toFixed(1)}` : "");

  const installsEl = el("span", { className: "protocol-installs" });
  installsEl.textContent = `${proto.installs ?? 0} installs`;

  const authorEl = el("span", { className: "protocol-author" });
  authorEl.textContent = `by ${proto.authorName ?? proto.author ?? "Unknown"}`;

  meta.append(priceEl, ratingEl, installsEl, authorEl);

  const installBtn = el("button", { className: "protocol-install-btn" });
  installBtn.type = "button";
  installBtn.textContent = proto.price === 0 ? "Install" : `Buy ${proto.price} $RES`;
  installBtn.addEventListener("click", async () => {
    installBtn.disabled = true;
    installBtn.textContent = "Installing\u2026";
    const walletAddr = getWalletAddr() ?? "anonymous";
    try {
      if (proto.price > 0) {
        // Human-gated: show message, don't auto-install
        installBtn.textContent = "Purchase (bridge)";
        await bridgeRequest("/store/install", {
          method: "POST",
          body: { protocolId: proto.id, walletAddress: walletAddr },
        });
        installBtn.textContent = "Purchased!";
      } else {
        await bridgeRequest("/store/install", {
          method: "POST",
          body: { protocolId: proto.id, walletAddress: walletAddr },
        });
        installBtn.textContent = "Installed \u2713";
      }
      // Refresh after short delay to show updated install count
      setTimeout(() => void refreshStore(), 1200);
    } catch (err) {
      installBtn.disabled = false;
      installBtn.textContent = proto.price === 0 ? "Install" : `Buy ${proto.price} $RES`;
      console.warn("[store] install error:", err);
    }
  });

  footer.append(meta, installBtn);
  card.append(header, desc, footer);
  return card;
};

const renderProtocolGrid = (protocols) => {
  if (!PROTOCOL_GRID) return;
  PROTOCOL_GRID.replaceChildren();
  if (!protocols.length) {
    PROTOCOL_GRID.append(el("span", { className: "store-placeholder", text: "No protocols found." }));
    return;
  }
  for (const proto of protocols) {
    PROTOCOL_GRID.append(renderProtocolCard(proto));
  }
};

const refreshStore = async () => {
  if (!PROTOCOL_GRID) return;
  PROTOCOL_GRID.replaceChildren(el("span", { className: "store-placeholder", text: "Loading\u2026" }));
  try {
    const query = STORE_SEARCH_INPUT?.value.trim() ?? "";
    if (_storeTab === "owned") {
      const walletAddr = getWalletAddr() ?? "anonymous";
      const result = await bridgeRequest(`/store/owned?address=${encodeURIComponent(walletAddr)}`);
      _storeProtocols = result.protocols ?? [];
    } else {
      const params = new URLSearchParams();
      if (_storeCategory) params.set("category", _storeCategory);
      if (query) params.set("q", query);
      const qs = params.toString();
      const result = await bridgeRequest(`/store/protocols${qs ? "?" + qs : ""}`);
      _storeProtocols = result.protocols ?? [];
    }
    renderProtocolGrid(_storeProtocols);
  } catch (err) {
    if (!PROTOCOL_GRID) return;
    PROTOCOL_GRID.replaceChildren(
      el("span", { className: "panel-section-error", text: `Store unavailable: ${String(err.message ?? err)}` })
    );
  }
};

// Category filter buttons
if (STORE_CATEGORY_FILTERS) {
  STORE_CATEGORY_FILTERS.addEventListener("click", (e) => {
    const btn = e.target.closest(".store-cat-btn");
    if (!btn) return;
    _storeCategory = btn.dataset.cat ?? "";
    STORE_CATEGORY_FILTERS.querySelectorAll(".store-cat-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    void refreshStore();
  });
}

// Search input
if (STORE_SEARCH_INPUT) {
  let _storeSearchTimer = null;
  STORE_SEARCH_INPUT.addEventListener("input", () => {
    clearTimeout(_storeSearchTimer);
    _storeSearchTimer = setTimeout(() => void refreshStore(), 400);
  });
}

// Tabs
if (TAB_ALL) {
  TAB_ALL.addEventListener("click", () => {
    _storeTab = "all";
    TAB_ALL.classList.add("active");
    TAB_OWNED?.classList.remove("active");
    void refreshStore();
  });
}

if (TAB_OWNED) {
  TAB_OWNED.addEventListener("click", () => {
    _storeTab = "owned";
    TAB_OWNED.classList.add("active");
    TAB_ALL?.classList.remove("active");
    void refreshStore();
  });
}

// Submit form toggle
if (STORE_SUBMIT_BTN && STORE_SUBMIT_FORM) {
  STORE_SUBMIT_BTN.addEventListener("click", () => {
    STORE_SUBMIT_FORM.hidden = false;
    STORE_SUBMIT_BTN.hidden = true;
  });
}

if (STORE_SUBMIT_CANCEL && STORE_SUBMIT_FORM && STORE_SUBMIT_BTN) {
  STORE_SUBMIT_CANCEL.addEventListener("click", () => {
    STORE_SUBMIT_FORM.hidden = true;
    STORE_SUBMIT_BTN.hidden = false;
  });
}

if (STORE_SUBMIT_CONFIRM) {
  STORE_SUBMIT_CONFIRM.addEventListener("click", async () => {
    const name = document.getElementById("submit-name")?.value.trim();
    const desc = document.getElementById("submit-desc")?.value.trim();
    const category = document.getElementById("submit-category")?.value;
    const price = Number(document.getElementById("submit-price")?.value ?? 0);
    const walletAddr = getWalletAddr() ?? "anonymous";
    if (!name || !desc) {
      STORE_SUBMIT_CONFIRM.textContent = "Name + description required";
      setTimeout(() => { STORE_SUBMIT_CONFIRM.textContent = "Submit Protocol"; }, 2000);
      return;
    }
    STORE_SUBMIT_CONFIRM.disabled = true;
    STORE_SUBMIT_CONFIRM.textContent = "Submitting\u2026";
    try {
      await bridgeRequest("/store/protocols", {
        method: "POST",
        body: { name, description: desc, category, price, priceToken: "RES", author: walletAddr, authorName: walletAddr.slice(0, 8) + "\u2026" },
      });
      STORE_SUBMIT_CONFIRM.textContent = "Submitted \u2713";
      if (STORE_SUBMIT_FORM) STORE_SUBMIT_FORM.hidden = true;
      if (STORE_SUBMIT_BTN) STORE_SUBMIT_BTN.hidden = false;
      void refreshStore();
    } catch (err) {
      STORE_SUBMIT_CONFIRM.disabled = false;
      STORE_SUBMIT_CONFIRM.textContent = "Failed — retry";
      console.warn("[store] submit error:", err);
    } finally {
      setTimeout(() => {
        if (STORE_SUBMIT_CONFIRM) {
          STORE_SUBMIT_CONFIRM.disabled = false;
          STORE_SUBMIT_CONFIRM.textContent = "Submit Protocol";
        }
      }, 3000);
    }
  });
}

// Open trigger
if (STORE_SECTION) {
  STORE_SECTION.addEventListener("toggle", () => {
    if (STORE_SECTION.open) void refreshStore();
  });
}

// ===========================================================================
// Archive Panel
// ===========================================================================

const ARCHIVE_SECTION = document.getElementById("archive-section");
const ARCHIVE_SEARCH_INPUT = document.getElementById("archive-search-input");
const ARCHIVE_SEARCH_BTN = document.getElementById("archive-search-btn");
const ARCHIVE_RESULTS = document.getElementById("archive-results");
const ARCHIVE_INTAKES_LIST = document.getElementById("archive-intakes-list");
const ARCHIVE_WIKI_PAGES = document.getElementById("archive-wiki-pages");
const ARCHIVE_INTAKES_STAT = document.getElementById("archive-intakes");
const ARCHIVE_QUICK_SAVE = document.getElementById("archive-quick-save");

const renderArchiveResults = (matches) => {
  if (!ARCHIVE_RESULTS) return;
  ARCHIVE_RESULTS.replaceChildren();
  if (!matches || !matches.length) {
    ARCHIVE_RESULTS.append(el("p", { className: "panel-section-empty", text: "No matches found." }));
    return;
  }
  for (const match of matches) {
    const card = el("div", { className: "archive-result" });
    const title = el("p", { className: "archive-result-title", text: match.title ?? match.path ?? "Untitled" });
    const excerpt = el("p", { className: "archive-result-excerpt", text: match.excerpt ?? "" });
    card.append(title, excerpt);
    ARCHIVE_RESULTS.append(card);
  }
};

const runArchiveSearch = async () => {
  const query = ARCHIVE_SEARCH_INPUT?.value.trim() ?? "";
  if (!query || query.length < 2) return;
  if (ARCHIVE_RESULTS) ARCHIVE_RESULTS.replaceChildren(el("p", { className: "panel-section-loading", text: "Searching\u2026" }));
  try {
    const result = await bridgeRequest("/memory/search", {
      method: "POST",
      body: { query, limit: 6 },
    });
    renderArchiveResults(result.matches ?? []);
  } catch (err) {
    if (ARCHIVE_RESULTS) ARCHIVE_RESULTS.replaceChildren(el("p", { className: "panel-section-error", text: String(err.message ?? err) }));
  }
};

const refreshArchiveMeta = async () => {
  try {
    const [statusResult, intakesResult] = await Promise.all([
      bridgeRequest("/memory/status"),
      bridgeRequest("/memory/intakes"),
    ]);
    if (ARCHIVE_WIKI_PAGES) ARCHIVE_WIKI_PAGES.textContent = String(statusResult.wiki?.pages ?? 0);
    if (ARCHIVE_INTAKES_STAT) ARCHIVE_INTAKES_STAT.textContent = String(statusResult.intake?.artifacts ?? 0);

    // Render recent intakes list
    if (ARCHIVE_INTAKES_LIST) {
      const heading = el("div", { className: "archive-intakes-heading", text: "Recent Intakes" });
      ARCHIVE_INTAKES_LIST.replaceChildren(heading);
      const intakes = intakesResult.intakes ?? [];
      if (!intakes.length) {
        ARCHIVE_INTAKES_LIST.append(el("p", { className: "panel-section-empty", text: "No intakes yet." }));
      } else {
        for (const intake of intakes.slice(0, 5)) {
          const card = el("div", { className: "archive-intake-card" });
          const titleEl = el("div");
          titleEl.textContent = intake.title ?? intake.path ?? "Untitled";
          const dateEl = el("div", { className: "archive-intake-date" });
          dateEl.textContent = intake.createdAt ? new Date(intake.createdAt).toLocaleString() : "";
          card.append(titleEl, dateEl);
          ARCHIVE_INTAKES_LIST.append(card);
        }
      }
    }
  } catch (err) {
    console.warn("[archive] meta refresh error:", err);
  }
};

if (ARCHIVE_SEARCH_BTN) {
  ARCHIVE_SEARCH_BTN.addEventListener("click", () => void runArchiveSearch());
}

if (ARCHIVE_SEARCH_INPUT) {
  ARCHIVE_SEARCH_INPUT.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      void runArchiveSearch();
    }
  });
}

if (ARCHIVE_QUICK_SAVE) {
  ARCHIVE_QUICK_SAVE.addEventListener("click", async () => {
    ARCHIVE_QUICK_SAVE.disabled = true;
    ARCHIVE_QUICK_SAVE.textContent = "Saving\u2026";
    const snapshot = lastSnapshot;
    const title = snapshot?.title ?? document.title ?? "Browser page";
    const content = snapshot?.body ?? snapshot?.text ?? "No page content captured.";
    const pageUrl = snapshot?.url ?? "";
    try {
      await bridgeRequest("/archive/intake", {
        method: "POST",
        body: { title, content: content.slice(0, 10000), url: pageUrl },
      });
      ARCHIVE_QUICK_SAVE.textContent = "Saved \u2713";
      setTimeout(() => void refreshArchiveMeta(), 800);
    } catch (err) {
      ARCHIVE_QUICK_SAVE.textContent = "Failed";
      console.warn("[archive] quick save error:", err);
    } finally {
      setTimeout(() => {
        if (ARCHIVE_QUICK_SAVE) {
          ARCHIVE_QUICK_SAVE.disabled = false;
          ARCHIVE_QUICK_SAVE.textContent = "\u2913 Save Current Page";
        }
      }, 2500);
    }
  });
}

if (ARCHIVE_SECTION) {
  ARCHIVE_SECTION.addEventListener("toggle", () => {
    if (ARCHIVE_SECTION.open) void refreshArchiveMeta();
  });
}

// ===========================================================================
// R-Awareness Panel
// ===========================================================================

const AWARENESS_SECTION = document.getElementById("awareness-section");
const AW_BRIDGE = document.getElementById("aw-bridge");
const AW_MINIMAX = document.getElementById("aw-minimax");
const AW_OPENAI = document.getElementById("aw-openai");
const AW_WALLET = document.getElementById("aw-wallet");
const AW_WIKI = document.getElementById("aw-wiki");
const AW_INTAKES = document.getElementById("aw-intakes");
const AW_GOALS = document.getElementById("aw-goals");
const AW_DELEGATIONS = document.getElementById("aw-delegations");
const AW_PAGE = document.getElementById("aw-page");
const AW_MSGS = document.getElementById("aw-msgs");
const AW_UPDATED = document.getElementById("aw-updated");
const AW_REFRESH_BTN = document.getElementById("aw-refresh-btn");

let _awarenessTimer = null;

const setAwareness = (el, value, tone) => {
  if (!el) return;
  el.textContent = String(value ?? "\u2014");
  el.className = "awareness-value";
  if (tone) el.classList.add(tone);
};

const refreshAwareness = async () => {
  try {
    const result = await bridgeRequest("/status");

    // Bridge
    setAwareness(AW_BRIDGE, result.bridge ? "online" : "offline", result.bridge ? "online" : "offline");

    // Providers
    const minimax = result.providers?.["shared-minimax"];
    const openai = result.providers?.["shared-openai"];
    setAwareness(AW_MINIMAX, minimax ? "ready" : "missing", minimax ? "ready" : "missing");
    setAwareness(AW_OPENAI, openai ? "ready" : "missing", openai ? "ready" : "missing");

    // Memory
    setAwareness(AW_WIKI, result.memory?.wiki?.pages ?? 0, null);
    setAwareness(AW_INTAKES, result.memory?.intake?.artifacts ?? 0, null);

    // Records
    setAwareness(AW_GOALS, result.records?.goals ?? 0, null);
    setAwareness(AW_DELEGATIONS, result.records?.delegations ?? 0, null);

    // Wallet
    const walletState = getWalletState?.();
    const connected = walletState?.connected && walletState?.address;
    if (connected) {
      const addr = String(walletState.address);
      const short = addr.length >= 8 ? `${addr.slice(0, 4)}\u2026${addr.slice(-4)}` : addr;
      setAwareness(AW_WALLET, short, "ready");
    } else {
      setAwareness(AW_WALLET, "not connected", "missing");
    }

    // Current page
    const snap = lastSnapshot;
    const pageTitle = snap?.title ?? "\u2014";
    if (AW_PAGE) {
      AW_PAGE.textContent = pageTitle;
      AW_PAGE.className = "awareness-value awareness-page";
    }

    // Session messages
    const msgCount = Array.isArray(messages) ? messages.length : 0;
    setAwareness(AW_MSGS, String(msgCount), null);

    // Last updated
    if (AW_UPDATED) {
      AW_UPDATED.textContent = `Updated ${new Date().toLocaleTimeString()}`;
    }
  } catch (err) {
    if (AW_UPDATED) AW_UPDATED.textContent = `Error: ${String(err.message ?? err)}`;
    console.warn("[awareness] refresh error:", err);
  }
};

const startAwarenessAutoRefresh = () => {
  if (_awarenessTimer) return;
  _awarenessTimer = setInterval(() => {
    if (AWARENESS_SECTION?.open) void refreshAwareness();
  }, 60_000);
};

const stopAwarenessAutoRefresh = () => {
  if (_awarenessTimer) {
    clearInterval(_awarenessTimer);
    _awarenessTimer = null;
  }
};

if (AW_REFRESH_BTN) {
  AW_REFRESH_BTN.addEventListener("click", () => void refreshAwareness());
}

if (AWARENESS_SECTION) {
  AWARENESS_SECTION.addEventListener("toggle", () => {
    if (AWARENESS_SECTION.open) {
      void refreshAwareness();
      startAwarenessAutoRefresh();
    } else {
      stopAwarenessAutoRefresh();
    }
  });
}

// ===========================================================================
// Governance Panel
// ===========================================================================

const GOVERNANCE_SECTION = document.getElementById("governance-section");
const GOVERNANCE_BODY = document.getElementById("governance-body");

let _governanceData = { proposals: [], stats: {} };
let _govCreateFormVisible = false;

const formatExpiry = (isoString) => {
  if (!isoString) return "";
  const diff = new Date(isoString) - new Date();
  if (diff <= 0) return "Expired";
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days > 0) return `${days}d ${hours}h left`;
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return hours > 0 ? `${hours}h ${mins}m left` : `${mins}m left`;
};

const totalVotesFor = (proposal) =>
  (proposal.votesFor ?? []).reduce((s, v) => s + (v.weight ?? 1), 0);

const totalVotesAgainst = (proposal) =>
  (proposal.votesAgainst ?? []).reduce((s, v) => s + (v.weight ?? 1), 0);

const hasVoted = (proposal, walletAddress) => {
  if (!walletAddress) return false;
  return (
    (proposal.votesFor ?? []).some((v) => v.address === walletAddress) ||
    (proposal.votesAgainst ?? []).some((v) => v.address === walletAddress)
  );
};

const renderProposalCard = (proposal, walletAddress) => {
  const card = document.createElement("article");
  card.className = "proposal-card";

  // Title row
  const titleRow = document.createElement("div");
  titleRow.className = "proposal-title-row";
  const titleEl = document.createElement("span");
  titleEl.className = "proposal-title";
  titleEl.textContent = proposal.title;
  const statusEl = document.createElement("span");
  const statusLabel = proposal.status ?? "active";
  statusEl.className = `proposal-status ${statusLabel}`;
  const statusIcons = { active: "🟢", passed: "✅", rejected: "❌", expired: "⏰" };
  statusEl.textContent = `${statusIcons[statusLabel] ?? ""} ${statusLabel}`;
  titleRow.append(titleEl, statusEl);
  card.append(titleRow);

  // Description
  const descEl = document.createElement("p");
  descEl.className = "proposal-desc";
  descEl.textContent = proposal.description;
  card.append(descEl);

  // Progress bar
  const forCount = totalVotesFor(proposal);
  const threshold = proposal.threshold ?? 100;
  const fillPct = Math.min(100, Math.round((forCount / threshold) * 100));
  const progressWrap = document.createElement("div");
  progressWrap.className = "proposal-progress";
  const fill = document.createElement("div");
  fill.className = "proposal-progress-fill";
  fill.style.width = `${fillPct}%`;
  progressWrap.append(fill);
  card.append(progressWrap);

  // Meta row
  const meta = document.createElement("div");
  meta.className = "proposal-meta";
  const tallySpan = document.createElement("span");
  tallySpan.textContent = `${forCount} / ${threshold} votes`;
  const expirySpan = document.createElement("span");
  expirySpan.className = "proposal-expiry";
  expirySpan.textContent = formatExpiry(proposal.expiresAt);
  meta.append(tallySpan, expirySpan);
  card.append(meta);

  // Vote buttons (only for active proposals)
  if (statusLabel === "active") {
    const voteRow = document.createElement("div");
    voteRow.className = "proposal-vote-row";

    const voted = hasVoted(proposal, walletAddress);
    const notConnected = !walletAddress;

    const forBtn = document.createElement("button");
    forBtn.type = "button";
    forBtn.className = "vote-button for";
    forBtn.textContent = "✔ For";
    forBtn.disabled = voted || notConnected;
    forBtn.title = notConnected ? "Connect wallet to vote" : voted ? "Already voted" : "Vote for";
    forBtn.addEventListener("click", async () => {
      forBtn.disabled = true;
      againstBtn.disabled = true;
      try {
        await bridgeFetch("/governance/vote", {
          method: "POST",
          body: { proposalId: proposal.id, walletAddress: walletAddress ?? "anonymous", vote: "for", weight: 1 },
        });
        void refreshGovernance();
      } catch (err) {
        await addMessage("system", `Vote failed: ${err instanceof Error ? err.message : String(err)}`);
        forBtn.disabled = false;
        againstBtn.disabled = false;
      }
    });

    const againstBtn = document.createElement("button");
    againstBtn.type = "button";
    againstBtn.className = "vote-button against";
    againstBtn.textContent = "✘ Against";
    againstBtn.disabled = voted || notConnected;
    againstBtn.title = notConnected ? "Connect wallet to vote" : voted ? "Already voted" : "Vote against";
    againstBtn.addEventListener("click", async () => {
      forBtn.disabled = true;
      againstBtn.disabled = true;
      try {
        await bridgeFetch("/governance/vote", {
          method: "POST",
          body: { proposalId: proposal.id, walletAddress: walletAddress ?? "anonymous", vote: "against", weight: 1 },
        });
        void refreshGovernance();
      } catch (err) {
        await addMessage("system", `Vote failed: ${err instanceof Error ? err.message : String(err)}`);
        forBtn.disabled = false;
        againstBtn.disabled = false;
      }
    });

    const tallyEl = document.createElement("span");
    tallyEl.className = "vote-tally";
    tallyEl.textContent = `${forCount} for · ${totalVotesAgainst(proposal)} against`;

    voteRow.append(forBtn, againstBtn, tallyEl);
    card.append(voteRow);
  }

  return card;
};

const renderGovernanceCreateForm = () => {
  const form = document.createElement("div");
  form.className = "gov-create-form";
  if (!_govCreateFormVisible) form.hidden = true;

  const titleLabel = document.createElement("label");
  titleLabel.className = "gov-form-label";
  titleLabel.textContent = "Title";
  const titleInput = document.createElement("input");
  titleInput.type = "text";
  titleInput.className = "gov-form-input";
  titleInput.placeholder = "Proposal title…";
  titleInput.maxLength = 140;

  const descLabel = document.createElement("label");
  descLabel.className = "gov-form-label";
  descLabel.textContent = "Description";
  const descInput = document.createElement("textarea");
  descInput.className = "gov-form-textarea";
  descInput.placeholder = "What are you proposing and why?";
  descInput.rows = 3;

  const threshLabel = document.createElement("label");
  threshLabel.className = "gov-form-label";
  threshLabel.textContent = "Vote Threshold (default: 100)";
  const threshInput = document.createElement("input");
  threshInput.type = "number";
  threshInput.className = "gov-form-input";
  threshInput.value = "100";
  threshInput.min = "1";

  const actions = document.createElement("div");
  actions.className = "gov-form-actions";

  const cancelBtn = document.createElement("button");
  cancelBtn.type = "button";
  cancelBtn.className = "gov-form-cancel";
  cancelBtn.textContent = "Cancel";
  cancelBtn.addEventListener("click", () => {
    _govCreateFormVisible = false;
    void refreshGovernance();
  });

  const submitBtn = document.createElement("button");
  submitBtn.type = "button";
  submitBtn.className = "gov-form-submit";
  submitBtn.textContent = "Submit Proposal";
  submitBtn.addEventListener("click", async () => {
    const title = titleInput.value.trim();
    const description = descInput.value.trim();
    const threshold = Number(threshInput.value) || 100;
    if (!title || !description) {
      titleInput.focus();
      return;
    }
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting…";
    try {
      const walletAddress = getWalletAddr?.() ?? "anonymous";
      await bridgeFetch("/governance/proposals", {
        method: "POST",
        body: { title, description, threshold, walletAddress },
      });
      _govCreateFormVisible = false;
      void refreshGovernance();
    } catch (err) {
      await addMessage("system", `Create proposal failed: ${err instanceof Error ? err.message : String(err)}`);
      submitBtn.disabled = false;
      submitBtn.textContent = "Submit Proposal";
    }
  });

  actions.append(cancelBtn, submitBtn);
  form.append(titleLabel, titleInput, descLabel, descInput, threshLabel, threshInput, actions);
  return form;
};

const refreshGovernance = async () => {
  if (!GOVERNANCE_BODY) return;
  GOVERNANCE_BODY.replaceChildren();

  try {
    const [proposalsResult, statsResult] = await Promise.all([
      bridgeFetch("/governance/proposals"),
      bridgeFetch("/governance/stats"),
    ]);
    _governanceData = { proposals: proposalsResult.proposals ?? [], stats: statsResult };

    const walletAddress = getWalletAddr?.() ?? null;

    // Stats bar
    const statsBar = document.createElement("div");
    statsBar.className = "gov-stats-bar";
    const stats = _governanceData.stats;
    const statsSpan = document.createElement("span");
    statsSpan.textContent = `${stats.active ?? 0} Active`;
    const passedSpan = document.createElement("span");
    passedSpan.textContent = `${stats.passed ?? 0} Passed`;
    const rejectedSpan = document.createElement("span");
    rejectedSpan.textContent = `${stats.rejected ?? 0} Rejected`;
    const createBtn = document.createElement("button");
    createBtn.type = "button";
    createBtn.className = "gov-create-btn";
    createBtn.textContent = "+ Propose";
    createBtn.addEventListener("click", () => {
      _govCreateFormVisible = !_govCreateFormVisible;
      void refreshGovernance();
    });
    statsBar.append(statsSpan, passedSpan, rejectedSpan, createBtn);
    GOVERNANCE_BODY.append(statsBar);

    // Create form
    GOVERNANCE_BODY.append(renderGovernanceCreateForm());

    // Proposals list
    if (_governanceData.proposals.length === 0) {
      const empty = document.createElement("p");
      empty.className = "panel-section-empty";
      empty.textContent = "No proposals yet. Be the first to propose!";
      GOVERNANCE_BODY.append(empty);
    } else {
      const list = document.createElement("div");
      list.className = "proposal-list";
      for (const proposal of _governanceData.proposals) {
        list.append(renderProposalCard(proposal, walletAddress));
      }
      GOVERNANCE_BODY.append(list);
    }
  } catch (err) {
    const errEl = document.createElement("p");
    errEl.className = "panel-section-error";
    errEl.textContent = `Governance unavailable: ${err instanceof Error ? err.message : String(err)}`;
    GOVERNANCE_BODY.append(errEl);
  }
};

if (GOVERNANCE_SECTION) {
  GOVERNANCE_SECTION.addEventListener("toggle", () => {
    if (GOVERNANCE_SECTION.open) {
      void refreshGovernance();
    }
  });
}

// ===========================================================================
// Shield Panel
// ===========================================================================

const SHIELD_SECTION = document.getElementById("shield-section");
const SHIELD_BODY = document.getElementById("shield-body");

const formatEventType = (type) => {
  const map = {
    wallet_connect: "Wallet Connect",
    wallet_sign: "Wallet Sign",
    wallet_switch_network: "Switch Network",
    public_submit: "Public Submit",
    sensitive_type: "Sensitive Type",
    credential_autofill: "Credential Autofill",
    injection_attempt_detected: "Injection Attempt",
    rate_limit: "Rate Limit",
  };
  return map[type] ?? String(type ?? "Unknown").replace(/_/g, " ");
};

const formatShieldTime = (iso) => {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch {
    return iso.slice(0, 16).replace("T", " ");
  }
};

const renderShieldEvent = (event, fromStorage = false) => {
  const row = document.createElement("div");
  const approved = fromStorage ? null : event.approved;
  const eventType = fromStorage ? (event.type ?? "event") : event.action;

  let cls = "security-event";
  let icon = "🔒";
  if (fromStorage) {
    if (eventType === "injection_attempt_detected") { cls += " injection"; icon = "⚠️"; }
    else if (eventType === "rate_limit") { cls += " blocked"; icon = "🚫"; }
    else { cls += " blocked"; icon = "🛡️"; }
  } else {
    if (approved === false) { cls += " blocked"; icon = "🚫"; }
    else if (approved === true) { cls += " approved"; icon = "✅"; }
  }

  row.className = cls;

  const iconEl = document.createElement("span");
  iconEl.className = "security-event-icon";
  iconEl.textContent = icon;

  const body = document.createElement("div");
  body.className = "security-event-body";

  const typeEl = document.createElement("div");
  typeEl.className = "security-event-type";
  typeEl.textContent = formatEventType(eventType);

  const detailEl = document.createElement("div");
  detailEl.className = "security-event-detail";
  if (fromStorage) {
    detailEl.textContent = (event.snippet ?? event.url ?? "").slice(0, 80);
  } else {
    detailEl.textContent = (event.pageUrl ?? event.walletAddress ?? "").slice(0, 60);
  }

  body.append(typeEl, detailEl);

  const timeEl = document.createElement("span");
  timeEl.className = "security-event-time";
  timeEl.textContent = formatShieldTime(event.timestamp ?? event.ts);

  row.append(iconEl, body, timeEl);
  return row;
};

const refreshShield = async () => {
  if (!SHIELD_BODY) return;
  SHIELD_BODY.replaceChildren();

  try {
    // Fetch bridge shield status + chrome.storage.local securityLog in parallel
    const [shieldResult, storageResult] = await Promise.all([
      bridgeFetch("/shield/status"),
      chrome.storage?.local?.get?.(["securityLog"]).catch(() => ({})),
    ]);

    const securityLog = Array.isArray(storageResult?.securityLog) ? storageResult.securityLog : [];

    // Status header
    const headerRow = document.createElement("div");
    headerRow.className = "shield-header";
    const dot = document.createElement("span");
    dot.className = `shield-status-dot ${shieldResult.active ? "active" : "inactive"}`;
    const statusLbl = document.createElement("span");
    statusLbl.className = "shield-status-label";
    statusLbl.textContent = shieldResult.active ? "Shield Active" : "Shield Inactive";
    headerRow.append(dot, statusLbl);
    SHIELD_BODY.append(headerRow);

    // Stats row
    const statsRow = document.createElement("div");
    statsRow.className = "shield-stats-row";
    const blocksEl = document.createElement("span");
    blocksEl.textContent = `${shieldResult.stats?.totalBlocks ?? 0} Blocks`;
    const approvalsEl = document.createElement("span");
    approvalsEl.textContent = `${shieldResult.stats?.totalApprovals ?? 0} Approvals`;
    const rulesEl = document.createElement("span");
    rulesEl.textContent = `${shieldResult.rules ?? 0} Rules`;
    statsRow.append(blocksEl, approvalsEl, rulesEl);
    SHIELD_BODY.append(statsRow);

    // Approval gates
    const gatesTitle = document.createElement("div");
    gatesTitle.className = "shield-gates-title";
    gatesTitle.textContent = "Approval Gates";
    SHIELD_BODY.append(gatesTitle);

    const gateList = document.createElement("div");
    gateList.className = "shield-gate-list";
    for (const gate of shieldResult.approvalGates ?? []) {
      const item = document.createElement("div");
      item.className = "shield-gate-item";
      const check = document.createElement("span");
      check.className = "shield-gate-check";
      check.textContent = "✓";
      const label = document.createElement("span");
      label.textContent = formatEventType(gate);
      item.append(check, label);
      gateList.append(item);
    }
    SHIELD_BODY.append(gateList);

    // Security event log — merge bridge blocks + content script events
    const bridgeBlocks = shieldResult.recentBlocks ?? [];
    const mergedEvents = [
      ...securityLog.slice(-10).reverse().map((e) => ({ _fromStorage: true, ...e })),
      ...bridgeBlocks.map((e) => ({ _fromBridge: true, ...e })),
    ].slice(0, 10);

    const eventsTitle = document.createElement("div");
    eventsTitle.className = "shield-events-title";
    eventsTitle.textContent = "Recent Security Events";
    SHIELD_BODY.append(eventsTitle);

    const eventsList = document.createElement("div");
    eventsList.className = "shield-events-list";

    if (mergedEvents.length === 0) {
      const empty = document.createElement("p");
      empty.className = "shield-empty";
      empty.textContent = "No security events recorded.";
      eventsList.append(empty);
    } else {
      for (const event of mergedEvents) {
        eventsList.append(renderShieldEvent(event, Boolean(event._fromStorage)));
      }
    }
    SHIELD_BODY.append(eventsList);
  } catch (err) {
    const errEl = document.createElement("p");
    errEl.className = "panel-section-error";
    errEl.textContent = `Shield unavailable: ${err instanceof Error ? err.message : String(err)}`;
    SHIELD_BODY.append(errEl);
  }
};

if (SHIELD_SECTION) {
  SHIELD_SECTION.addEventListener("toggle", () => {
    if (SHIELD_SECTION.open) {
      void refreshShield();
    }
  });
}

// ── Resonator Visual Guide helpers ──────────────────────────────────────────

/**
 * sendResonatorCommand — sends a resonator command to the active tab's content script.
 * Ensures the content script (including resonator.js) is injected first.
 */
const sendResonatorCommand = async (type, payload) => {
  const tab = await activeTab();
  if (!tab?.id || !isReadableBrowserTab(tab)) {
    await addMessage('system', 'Resonator: no readable page active.');
    return { ok: false };
  }
  await ensureContentScriptInjected(tab.id);
  const result = await chrome.tabs.sendMessage(tab.id, {
    channel: 'resonantos.browser_first.content',
    type,
    ...payload,
  }).catch((err) => ({ ok: false, error: String(err) }));
  if (!result?.ok) {
    console.warn('[Resonator] command failed:', type, result?.error);
  }
  return result;
};

/**
 * parseResonatorMarkersFromReply — scans AI reply for [RESONATOR:cmd]{...}[/RESONATOR]
 * markers, sends each to the content script, and returns cleaned reply text.
 */
const parseResonatorMarkersFromReply = (text) => {
  if (!text || typeof text !== 'string') return text;
  const re = /\[RESONATOR:(\w+)\]([\s\S]*?)\[\/RESONATOR\]/gi;
  let clean = text;
  let match;
  while ((match = re.exec(text)) !== null) {
    const cmd = match[1].toLowerCase();
    const raw = match[2].trim();
    let payload = {};
    try { payload = JSON.parse(raw); } catch { payload = { text: raw }; }
    const typeMap = {
      highlight: 'resonator_highlight',
      arrow: 'resonator_arrow',
      spotlight: 'resonator_spotlight',
      step: 'resonator_step',
      steps: 'resonator_step',
      clear: 'resonator_clear',
    };
    const msgType = typeMap[cmd];
    if (msgType) {
      void sendResonatorCommand(msgType, payload);
    }
    clean = clean.replace(match[0], `*[Resonator: ${cmd}]*`);
  }
  return clean;
};

// ── Resonant Blackboard helpers ───────────────────────────────────────

let bbTabId = null;

/**
 * openBlackboard — opens the blackboard tab (or focuses it if already open).
 */
const openBlackboard = async () => {
  // Check if the tab is still alive
  if (bbTabId !== null) {
    const alive = await chrome.tabs.get(bbTabId).catch(() => null);
    if (alive) {
      await chrome.tabs.update(bbTabId, { active: true }).catch(() => undefined);
      return;
    }
    bbTabId = null;
  }
  // Search for an existing blackboard tab
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find((t) => t.url?.includes("blackboard.html"));
  if (existing) {
    bbTabId = existing.id;
    await chrome.tabs.update(bbTabId, { active: true }).catch(() => undefined);
    return;
  }
  // Create a new tab
  const bbUrl = chrome.runtime.getURL("src/blackboard.html");
  const tab = await chrome.tabs.create({ url: bbUrl });
  bbTabId = tab.id ?? null;
};

/**
 * sendToBlackboard — sends a command + payload to the blackboard tab.
 * Opens the blackboard first if needed.
 */
const sendToBlackboard = async (command, payload) => {
  await openBlackboard();
  // Allow the blackboard tab a moment to load if it was just created
  await new Promise((resolve) => window.setTimeout(resolve, 600));
  chrome.runtime.sendMessage({
    channel: "resonantos.blackboard.relay",
    payload: { channel: "resonantos.blackboard", command, payload }
  }).catch(() => undefined);
};

/**
 * parseBlackboardMarkersFromReply — scans AI reply text for [BLACKBOARD:cmd]...[/BLACKBOARD]
 * markers, sends each to the blackboard tab, and returns the cleaned reply text.
 */
const parseBlackboardMarkersFromReply = (text) => {
  if (!text || typeof text !== "string") return text;
  const re = /\[BLACKBOARD:(\w+)\]([\s\S]*?)\[\/BLACKBOARD\]/gi;
  let clean = text;
  let match;
  let found = false;
  while ((match = re.exec(text)) !== null) {
    found = true;
    const cmd = match[1].toLowerCase();
    const raw = match[2].trim();
    let payload = {};
    try { payload = JSON.parse(raw); } catch {
      if (cmd === "document" || cmd === "doc") payload = { markdown: raw };
      else payload = { markdown: raw };
    }
    // Open blackboard and relay (fire-and-forget)
    void sendToBlackboard(cmd, payload);
    clean = clean.replace(match[0], `\n*[Displayed on Blackboard \u25c8]*\n`);
  }
  return clean;
};
